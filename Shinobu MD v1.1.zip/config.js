const fs = require("fs");

// ═══════════════════════════════════════════
//  Shinobu MD V1 — Config
// ═══════════════════════════════════════════

// ── INFO BOT ──────────────────────────────
global.botname      = "Shinobu MD V1"
global.versibot     = "1.0.0"
global.ownername    = "dekzymarket"         // Global Owner
global.owner        = "6285835425541"     // Nomor owner (format: 62xxx)
global.pairingNumber = "6285835425541"  // Nomor WA yang di-pair

// ── LINK ──────────────────────────────────
global.linkChannel  = "https://whatsapp.com/channel/0029VbCgjWUFXUuRf0RRCW1h"
global.idChannel    = "120363427915199733@newsletter"
global.linkGrup     = "https://chat.whatsapp.com/HK56HeTkb9O0XalmSIi5Ne?s=cl&p=a&ilr=1"
global.thumbnail    = "https://files.catbox.moe/a4mdxx.jpg"


// ── PREFIX & MODE ─────────────────────────
global.prefix       = "."                        // prefix
global.mode         = "public"               // public / self

// ── STICKER ───────────────────────────────
global.packname     = "Shinobu MD V1"
global.author       = "Owner"

// ── PAYMENT ───────────────────────────────
global.dana         = "087883313554"
global.ovo          = "0812xxxxxxxx"
global.gopay        = "0812xxxxxxxx"
global.qris         = ""                     // URL gambar QRIS

// ── PTERODACTYL PANEL ─────────────────────
global.domain       = "https://"                  // domain 
global.apikey       = "plta_"                     // ptla_
global.capikey      = "pltc"                     // ptlc_xxx
global.egg          = "15"
global.nestid       = "5"
global.loc          = "1"

// ── API KEYS ──────────────────────────────
global.groqApiKey   = ""    // https://console.groq.com
global.geminiApiKey = ""    // https://aistudio.google.com/apikey
global.cukiApiKey   = ""    // https://cuki.biz.id (untuk .caribug)

// ── FITUR OURIN: ENERGI/LIMIT ─────────────
global.energiDefault  = 50   // Limit default per hari
global.energiPremium  = 500  // Limit premium per hari
global.energiOwner    = -1   // -1 = unlimited

// ── FITUR OURIN: REGISTRASI ───────────────
global.registrasiEnabled = false   // true = user harus daftar dulu
global.registrasiReward  = { koin: 1000, energi: 100, exp: 1000 }

// ── FITUR OURIN: GROUP PROTECTION ─────────
global.pesan = {
  antilink       : "⚠ *Antilink* — @%user% mengirim link. Pesan dihapus.",
  antilinkKick   : "⚠ *Antilink* — @%user% di-kick karena mengirim link.",
  antitagsw      : "⚠ *AntiTagSW* — Tag status dari @%user% dihapus.",
  antitoxic      : "⚠ @%user% berkata kasar. Peringatan ke %warn% dari %max%.",
  antidocument   : "⚠ *AntiDokumen* — Dokumen dari @%user% dihapus.",
  antisticker    : "⚠ *AntiStiker* — Stiker dari @%user% dihapus.",
  antimedia      : "⚠ *AntiMedia* — Media dari @%user% dihapus.",
}

// ── FITUR OTOMATIS ────────────────────────
global.autoTyping    = true
global.autoRead      = true
global.antiCall      = false    // true = tolak panggilan masuk
global.blockIfCall   = false    // true = blokir yang telepon

// ── WELCOME / GOODBYE DEFAULT ─────────────
global.welcomeDefault = false
global.goodbyeDefault = false

// ── SCHEDULER RESET LIMIT ─────────────────
global.resetHour   = 0    // Jam reset limit (0 = tengah malam)
global.resetMinute = 0

// ── DATABASE ──────────────────────────────
global.dbPath = "./database"

// ── HOT RELOAD ────────────────────────────
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  delete require.cache[file]
  require(file)
})

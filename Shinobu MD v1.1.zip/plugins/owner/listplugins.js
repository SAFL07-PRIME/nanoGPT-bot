const fs = require("fs")
const path = require("path")

function scanPlugins(dir) {
  let results = []
  let files = fs.readdirSync(dir)

  for (let file of files) {
    let fullPath = path.join(dir, file)

    if (fs.lstatSync(fullPath).isDirectory()) {
      results = results.concat(scanPlugins(fullPath))
    } else if (file.endsWith(".js") || file.endsWith(".cjs")) {
      results.push(fullPath)
    }
  }

  return results
}

let handler = async (m, { sock, isOwner }) => {
  if (!isOwner) return

  let pluginDir = "./plugins"
  let plugins = scanPlugins(pluginDir)

  if (!plugins.length) {
    return sock.sendMessage(
      m.chat,
      { text: "Tidak ada plugin ditemukan." },
      { quoted: m }
    )
  }

  let list = plugins
    .map((p, i) => `${i + 1}. ${path.relative(pluginDir, p)}`)
    .join("\n")

  await sock.sendMessage(
    m.chat,
    { text: `${list}` },
    { quoted: m }
  )
}

handler.tags = "owner"
handler.help = "listplugin"
handler.command = ["listplugin", "listp"]
handler.owner = true

module.exports = handler
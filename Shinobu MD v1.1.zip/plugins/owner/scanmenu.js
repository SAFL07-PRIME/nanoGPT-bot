// plugins/owner/auto-register-menu.js
const fs = require('fs');
const path = require('path');

const handler = async (m, { reply, usedPrefix, command }) => {
  
  if (command === 'scanmenu') {
    // Scan semua plugin di folder
    const pluginsDir = path.join(process.cwd(), 'plugins');
    let found = 0;
    let registered = 0;
    
    function scanDir(dir) {
      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
          scanDir(filePath);
        } else if (file.endsWith('.js')) {
          found++;
          try {
            const content = fs.readFileSync(filePath, 'utf-8');
            
            // Cek apakah plugin sudah memiliki tags
            if (!content.includes('handler.tags')) {
              // Tambahkan tags default
              const folderName = path.basename(path.dirname(filePath));
              const defaultTag = folderName || 'tools';
              
              // Tambahkan tags ke file
              const updated = content.replace(
                /handler\.command\s*=\s*\[([^\]]+)\]/,
                (match, cmds) => {
                  const tags = `handler.tags = ["${defaultTag}"];`;
                  const help = `handler.help = ${cmds.trim()};`;
                  return `${match}\n${tags}\n${help}`;
                }
              );
              
              if (updated !== content) {
                fs.writeFileSync(filePath, updated);
                registered++;
              }
            }
          } catch (e) {
            console.log(`Error register ${file}:`, e.message);
          }
        }
      }
    }
    
    scanDir(pluginsDir);
    
    return reply(`✅ *SCAN COMPLETE*\n\n` +
                `📁 Total Plugin: ${found}\n` +
                `📝 Registered: ${registered}\n` +
                `🔄 Restart bot untuk melihat perubahan!`);
  }
};

handler.command = ['scanmenu', 'regall'];
handler.owner = true;

module.exports = handler;
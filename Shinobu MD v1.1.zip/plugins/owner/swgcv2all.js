// plugins/swgcv2all.js — Status Grup V2 (Ring Pink) ke SEMUA grup, dari Ourin MD 3.1
const { generateWAMessage } = require("dekzymarket-cyber");
const { fileTypeFromBuffer } = require("file-type");

function buildSyntheticSwGcRawMessage(sock, remoteJid, innerMessage, messageId) {
  const botJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
  return {
    key: { remoteJid, fromMe: true, id: messageId, participant: botJid },
    message: { groupStatusMessageV2: { message: innerMessage } },
    messageTimestamp: Math.floor(Date.now() / 1000),
  };
}

let handler = async (m, { sock, text }) => {
  const qmsg = m.quoted || m;
  const mime = qmsg.mime || qmsg.msg?.mimetype || "";
  let rawContent = null;

  if (/image|video|audio/.test(mime)) {
    let buffer;
    try {
      buffer = m.quoted ? await m.quoted.download() : await m.download();
    } catch {}
    if (!buffer) return m.reply("❌ Gagal mengunduh media. Silakan coba lagi.");

    const fileType = await fileTypeFromBuffer(buffer);
    const detectedMime = fileType ? fileType.mime : mime;

    if (detectedMime.startsWith("image/")) {
      rawContent = { image: buffer, caption: text };
    } else if (detectedMime.startsWith("video/")) {
      rawContent = { video: buffer, caption: text };
    } else if (detectedMime.startsWith("audio/")) {
      rawContent = { audio: buffer, mimetype: "audio/mpeg", ptt: qmsg.msg?.ptt || false };
    } else {
      return m.reply("❌ Format media tidak didukung untuk SW GC.");
    }
  } else if (text) {
    rawContent = { text };
  } else {
    return m.reply(
      `👋 *sᴡɢᴄᴠ2 ᴀʟʟ ɢʟᴏʙᴀʟ*\n\n` +
      `> Kirim pesan *Status Grup V2 (Ring Pink)* ke SEMUA grup sekaligus.\n\n` +
      `╭┈┈⬡「 📋 *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ* 」\n` +
      `┃ ${m.cmd} Halo semua!\n` +
      `┃ atau reply gambar/video dengan caption ${m.cmd}\n` +
      `╰┈┈┈┈┈┈┈┈⬡`
    );
  }

  await m.react("🕕");

  try {
    const groups = await sock.groupFetchAllParticipating();
    const groupIds = Object.keys(groups);

    if (groupIds.length === 0) {
      await m.react("❌");
      return m.reply("❌ Bot tidak berada di grup manapun.");
    }

    await m.reply(`⏳ *Memulai Broadcast Status Grup V2 ke ${groupIds.length} Grup...*\n\n> Proses ini mungkin memakan waktu beberapa saat.`);

    let successCount = 0, failCount = 0;

    for (const targetGroupId of groupIds) {
      try {
        let baseContent = {};
        if (rawContent.image) baseContent = { image: rawContent.image, caption: rawContent.caption || "" };
        else if (rawContent.video) baseContent = { video: rawContent.video, caption: rawContent.caption || "" };
        else if (rawContent.audio) baseContent = { audio: rawContent.audio, mimetype: rawContent.mimetype || "audio/mpeg", ptt: rawContent.ptt || false };
        else if (rawContent.text) baseContent = { text: rawContent.text };

        const genMsg = await generateWAMessage(targetGroupId, baseContent, {
          userJid: sock.user.id,
          upload: sock.waUploadToServer,
        });

        const msgType = Object.keys(genMsg.message).find(
          (k) => k.endsWith("Message") && k !== "senderKeyDistributionMessage"
        );

        let mediaMessage = {};
        if (msgType) {
          mediaMessage[msgType] = genMsg.message[msgType];
          const newContextInfo = {
            isGroupStatus: true,
            statusSourceType: rawContent.text ? 4 : rawContent.audio ? 3 : rawContent.video ? 1 : 0,
            featureEligibilities: { canBeReshared: true, canBeSentToParticipants: true },
            statusAttributions: [{ type: 10 }],
            statusAudienceMetadata: { audienceType: 1 },
          };
          if (mediaMessage[msgType].contextInfo) {
            Object.assign(mediaMessage[msgType].contextInfo, newContextInfo);
          } else {
            mediaMessage[msgType].contextInfo = newContextInfo;
          }
        }

        const messageId = genMsg.key.id;
        const finalMessage = buildSyntheticSwGcRawMessage(sock, targetGroupId, mediaMessage, messageId);

        await sock.relayMessage(targetGroupId, finalMessage.message, { messageId });
        successCount++;
      } catch {
        failCount++;
      }
    }

    await m.react("✅");
    await m.reply(
      `✅ *sᴡɢᴄᴠ2 ᴀʟʟ sᴇʟᴇsᴀɪ*\n\n` +
      `╭┈┈⬡「 📊 *ʀᴇsᴜʟᴛ* 」\n` +
      `┃ 🌐 Total Grup: *${groupIds.length}*\n` +
      `┃ ✅ Sukses: *${successCount}*\n` +
      `┃ ❌ Gagal: *${failCount}*\n` +
      `╰┈┈┈┈┈┈┈┈⬡\n\n` +
      `> Broadcast Status Grup V2 (Ring Pink) berhasil dikirim ke semua grup!`
    );
  } catch (error) {
    console.error("[SwgcV2All] Error:", error.message);
    await m.react("☢");
    await m.reply("❌ Gagal broadcast: " + error.message);
  }
};

handler.command = ["swgcv2all", "statusgrupv2all"];
handler.tags = ["owner"];
handler.help = ["swgcv2all <teks>", "swgcv2all (reply media)"];
handler.owner = true;
module.exports = handler;

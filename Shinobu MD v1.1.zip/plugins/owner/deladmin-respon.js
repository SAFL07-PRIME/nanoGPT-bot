let handler = async (m, { text }) => {
  if (!text) return m.reply("ID admin tidak ditemukan")

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    })

    const data = await res.json()
    const users = data.data

    let target = users.find(
      u => u.attributes.id == text && u.attributes.root_admin === true
    )

    if (!target) {
      return m.reply("Gagal menghapus admin!\nID tidak ditemukan")
    }

    const id = target.attributes.id
    const username = target.attributes.username

    const del = await fetch(`${domain}/api/application/users/${id}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    })

    if (!del.ok) {
      const errData = await del.json()
      return m.reply(`Gagal hapus admin!\n${JSON.stringify(errData.errors[0], null, 2)}`)
    }

    m.reply(`Berhasil Menghapus Admin Panel ✅\nID User: ${id}\nNama: ${global.capital(username)}`)

  } catch (err) {
    console.error(err)
    m.reply("Terjadi kesalahan saat menghapus admin.")
  }
}

handler.command = ['deladmin-response']
handler.tags = ["plugins"];
handler.help = 'deladmin-response';
handler.owner = true

module.exports = handler
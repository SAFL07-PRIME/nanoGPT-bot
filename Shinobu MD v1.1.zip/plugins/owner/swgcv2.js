// plugins/swgcv2.js — Status Grup V2 (Ring Pink) dari Ourin MD 3.1
// Pilih 1 grup spesifik untuk di-post statusnya
const { generateWAMessage } = require("dekzymarket-cyber");
const { fileTypeFromBuffer } = require("file-type");

if (!global.pendingSwgcV2) global.pendingSwgcV2 = new Map();

let handler = async (m, { sock, args, text }) => {

  // ── Konfirmasi pilih grup ────────────────
  if (args[0] === "--confirm" && args[1]) {
    const targetGroupId = args[1];
    const pendingData = global.pendingSwgcV2.get(m.sender);

    if (!pendingData) {
      return m.reply("⚠️ *Tidak ada data pending.* Silakan kirim ulang media + .swgcv2");
    }

    try {
      let groupName = "Grup";
      try {
        const meta = await sock.groupMetadata(targetGroupId);
        groupName = meta.subject;
      } catch {}

      await m.react("🕕");

      const rawContent = pendingData.rawContent;
      let baseContent = {};
      if (rawContent.image) baseContent = { image: rawContent.image, caption: rawContent.caption || "" };
      else if (rawContent.video) baseContent = { video: rawContent.video, caption: rawContent.caption || "" };
      else if (rawContent.audio) baseContent = { audio: rawContent.audio, mimetype: rawContent.mimetype || "audio/mpeg", ptt: rawContent.ptt || false };
      else if (rawContent.text) baseContent = { text: rawContent.text };

      const genMsg = await generateWAMessage(targetGroupId, baseContent, {
        userJid: sock.user.id,
        upload: sock.waUploadToServer,
      });

      const msgType = Object.keys(genMsg.message).find(
        (k) => k.endsWith("Message") && k !== "senderKeyDistributionMessage"
      );

      let mediaMessage = {};
      if (msgType) {
        mediaMessage[msgType] = genMsg.message[msgType];
        const newContextInfo = {
          isGroupStatus: true,
          statusSourceType: rawContent.text ? 4 : rawContent.audio ? 3 : rawContent.video ? 1 : 0,
          featureEligibilities: { canBeReshared: true, canReceiveMultiReact: false },
          statusAttributions: [{ type: 10 }],
          statusAudienceMetadata: { audienceType: 1 },
        };
        if (mediaMessage[msgType].contextInfo) {
          Object.assign(mediaMessage[msgType].contextInfo, newContextInfo);
        } else {
          mediaMessage[msgType].contextInfo = newContextInfo;
        }
      }

      const payload = { groupStatusMessageV2: { message: mediaMessage } };
      const messageId = genMsg.key.id;

      await sock.relayMessage(targetGroupId, payload, { messageId });

      await m.reply(`✅ Berhasil up SW (V2 Ring Pink) ke grup *${groupName}*`);
      global.pendingSwgcV2.delete(m.sender);
    } catch (error) {
      await m.reply(`❌ *Error*\n\n> Gagal posting story V2.\n> _${error.message}_`);
    }
    return;
  }

  // ── Ambil media / teks ───────────────────
  let rawContent = {};
  const qmsg = m.quoted || m;
  const mime = qmsg.mime || qmsg.msg?.mimetype || "";

  if (/image|video|audio/.test(mime)) {
    try {
      const buffer = m.quoted ? await m.quoted.download() : await m.download();
      if (!buffer) return m.reply("❌ Gagal mengambil media.");
      const fileType = await fileTypeFromBuffer(buffer);

      if (mime.startsWith("image")) {
        rawContent.image = buffer;
        rawContent.caption = text || "";
      } else if (mime.startsWith("video")) {
        rawContent.video = buffer;
        rawContent.caption = text || "";
      } else if (mime.startsWith("audio")) {
        rawContent.audio = buffer;
        rawContent.mimetype = fileType?.mime || mime || "audio/mpeg";
        rawContent.ptt = qmsg.msg?.ptt || false;
      }
    } catch (e) {
      return m.reply("❌ Gagal mengunduh media: " + e.message);
    }
  } else if (text && text.trim() && args[0] !== "--confirm") {
    rawContent.text = text;
  } else {
    return m.reply(
      `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
      `> \`${m.cmd} teks\` - Story teks\n` +
      `> Reply gambar/video/audio + \`${m.cmd}\`\n` +
      `> Kirim gambar/video + caption \`${m.cmd}\``
    );
  }

  global.pendingSwgcV2.set(m.sender, { rawContent, timestamp: Date.now() });

  try {
    const groups = await sock.groupFetchAllParticipating();
    const groupList = Object.entries(groups);

    if (groupList.length === 0) return m.reply("⚠️ *Bot tidak berada di grup manapun.*");

    const groupRows = groupList.map(([id, meta]) => ({
      title: meta.subject || "Unknown Group",
      description: id,
      id: `${global.prefix}swgcv2 --confirm ${id}`,
    }));

    const mediaType = rawContent.text ? "Teks" : rawContent.image ? "Gambar" : rawContent.video ? "Video" : rawContent.audio ? "Audio" : "Media";

    await sock.relayMessage(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {},
          interactiveMessage: {
            header: { title: "📋 Pilih Grup untuk Post Story V2", hasMediaAttachment: false },
            body: { text: `> Media: *${mediaType}*\n> Total Grup: *${groupList.length}*\n\n_Pilih grup dari daftar di bawah:_` },
            footer: { text: global.botname },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "🏠 Pilih Grup",
                    sections: [{ title: "Daftar Grup", rows: groupRows }],
                  }),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "❌ Batal",
                    id: `${global.prefix}cancelswgcv2`,
                  }),
                },
              ],
            },
          },
        },
      },
    }, {});
  } catch (error) {
    await m.reply(`❌ *Error*\n\n> Gagal mengambil daftar grup.\n> _${error.message}_`);
    global.pendingSwgcV2.delete(m.sender);
  }
};

handler.command = ["swgcv2", "statusgrupv2"];
handler.tags = ["owner"];
handler.help = ["swgcv2 <teks>", "swgcv2 (reply media)"];
handler.owner = true;
module.exports = handler;

// plugins/info-gempa.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  await m.react("🌍");

  try {
    const { data } = await axios.get(
      "https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json",
      { timeout: 10000 }
    );

    const g = data?.Infogempa?.gempa;
    if (!g) throw new Error("Data tidak tersedia");

    const teks =
      `🌍 *INFO GEMPA TERKINI*\n` +
      `_Sumber: BMKG_\n\n` +
      `╭┈┈⬡「 📊 *DETAIL GEMPA* 」\n` +
      `┃ 📅 Tanggal: *${g.Tanggal}*\n` +
      `┃ ⏰ Waktu: *${g.Jam}*\n` +
      `┃ 📍 Lintang: *${g.Lintang}*\n` +
      `┃ 📍 Bujur: *${g.Bujur}*\n` +
      `┃ 💥 Magnitudo: *${g.Magnitude} SR*\n` +
      `┃ 🔻 Kedalaman: *${g.Kedalaman}*\n` +
      `┃ 📌 Wilayah: *${g.Wilayah}*\n` +
      `┃ 🌊 Potensi Tsunami: *${g.Potensi}*\n` +
      `╰┈┈⬡\n\n` +
      `> _Data ini bersumber dari BMKG. Selalu waspada!_ 🙏`;

    if (g.Shakemap) {
      const mapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${g.Shakemap}`;
      const buf = await axios.get(mapUrl, { responseType: "arraybuffer", timeout: 10000 })
        .then(r => Buffer.from(r.data)).catch(() => null);
      if (buf) {
        await sock.sendMessage(m.chat, { image: buf, caption: teks }, { quoted: m });
        return await m.react("✅");
      }
    }

    await m.reply(teks);
    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal mengambil info gempa: " + err.message);
  }
};

handler.command = ["gempa", "infobmkg", "bmkg"];
handler.tags = ["info"];
handler.help = ["gempa"];
module.exports = handler;

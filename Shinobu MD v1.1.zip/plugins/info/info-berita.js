// plugins/info-berita.js — Berita Terkini dari Ourin MD 3.1
const axios = require("axios");
const cheerio = require("cheerio");

const NEWS_SOURCES = {
  antara: { url: "https://www.antaranews.com/rss/terkini.xml", name: "Antara News", emoji: "📰" },
  cnn: { url: "https://www.cnnindonesia.com/nasional/rss", name: "CNN Indonesia", emoji: "📺" },
  cnbc: { url: "https://www.cnbcindonesia.com/rss", name: "CNBC Indonesia", emoji: "💹" },
  sindonews: { url: "https://international.sindonews.com/rss", name: "Sindo News", emoji: "📰" },
};

async function fetchRSS(url) {
  const response = await axios.get(url, {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
    timeout: 15000,
  });
  const $ = cheerio.load(response.data, { xmlMode: true });
  const items = [];
  $("item").each((i, el) => {
    if (i >= 10) return false;
    const title = $(el).find("title").text().trim();
    const link = $(el).find("link").text().trim();
    const pubDate = $(el).find("pubDate").text().trim();
    const description = $(el).find("description").text().trim().replace(/<[^>]*>/g, "").substring(0, 150);
    if (title && link) items.push({ title, link, pubDate, description });
  });
  return items;
}

function formatDate(dateStr) {
  try {
    return new Date(dateStr).toLocaleString("id-ID", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return dateStr;
  }
}

let handler = async (m, { command, text }) => {
  let source = command;

  if (command === "berita") {
    const arg = (text || "").toLowerCase().trim();
    if (!arg) {
      let txt = `📰 *ᴅᴀꜰᴛᴀʀ sᴜᴍʙᴇʀ ʙᴇʀɪᴛᴀ*\n\n`;
      for (const [key, val] of Object.entries(NEWS_SOURCES)) {
        txt += `> ${val.emoji} \`${m.prefix}${key}\` - ${val.name}\n`;
      }
      txt += `\n_Atau gunakan: \`${m.prefix}berita <sumber>\`_`;
      return m.reply(txt);
    }
    if (!NEWS_SOURCES[arg]) return m.reply(`❌ Sumber berita tidak ditemukan.\n> Gunakan: \`${m.prefix}berita\` untuk melihat daftar.`);
    source = arg;
  }

  const newsSource = NEWS_SOURCES[source];
  if (!newsSource) return m.reply("❌ Sumber berita tidak valid.");

  await m.react("🕕");

  try {
    const articles = await fetchRSS(newsSource.url);
    if (articles.length === 0) return m.reply("❌ Tidak ada berita ditemukan.");

    let txt = `${newsSource.emoji} *${newsSource.name.toUpperCase()}*\n━━━━━━━━━━━━━━━\n\n`;
    for (let i = 0; i < Math.min(articles.length, 7); i++) {
      const a = articles[i];
      txt += `*${i + 1}. ${a.title}*\n`;
      if (a.description) txt += `${a.description.trim()}...\n`;
      txt += `🔗 ${a.link}\n`;
      if (a.pubDate) txt += `📅 _${formatDate(a.pubDate)}_\n`;
      txt += `\n`;
    }
    txt += `━━━━━━━━━━━━━━━\n_Total: ${articles.length} artikel tersedia_`;

    await m.react("📰");
    return m.reply(txt);
  } catch (e) {
    await m.react("☢");
    return m.reply("❌ Gagal ambil berita: " + e.message);
  }
};

handler.command = ["berita", "antara", "cnn", "cnbc", "sindonews"];
handler.tags = ["info"];
handler.help = ["berita", "berita <sumber>"];
module.exports = handler;

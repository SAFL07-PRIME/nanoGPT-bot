// plugins/tools-qrcode.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  const text = (m.text || "").trim();
  if (!text) return m.reply(
    `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
    `> \`${m.cmd} <teks/url>\`\n\n` +
    `*Contoh:*\n` +
    `> \`${m.cmd} https://wa.me/628xxx\`\n` +
    `> \`${m.cmd} Hello World\``
  );

  await m.react("🕕");

  try {
    // Pakai api.qrserver.com (gratis, no key)
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}&color=000000&bgcolor=ffffff&margin=20`;
    const res = await axios.get(qrUrl, { responseType: "arraybuffer", timeout: 15000 });
    const buf = Buffer.from(res.data);

    await m.react("✅");
    await sock.sendMessage(m.chat, {
      image: buf,
      caption: `✅ *QR Code Generated!*\n\n📝 Data: \`${text.length > 50 ? text.slice(0, 50) + "..." : text}\``,
    }, { quoted: m });
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal generate QR: " + err.message);
  }
};

handler.command = ["qrcode", "qrcustom", "qr", "buatqr"];
handler.tags = ["tools"];
handler.help = ["qrcode <teks/url>"];
module.exports = handler;

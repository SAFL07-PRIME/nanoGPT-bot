// plugins/translate.js — dari Ourin MD 3
const axios = require("axios");

async function translate(text, to = "id", from = "auto") {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${from}&tl=${to}&dt=t&q=${encodeURIComponent(text)}`;
  const { data } = await axios.get(url);
  return data[0].map((i) => i[0]).join("");
}

const langList = {
  id: "Indonesia", en: "English", ja: "Jepang", ko: "Korea",
  zh: "China", ar: "Arab", fr: "Prancis", de: "Jerman",
  es: "Spanyol", pt: "Portugis", ru: "Rusia", it: "Italia",
  nl: "Belanda", th: "Thailand", ms: "Malaysia", vi: "Vietnam",
  hi: "Hindi", tr: "Turki", pl: "Polandia", sv: "Swedia",
};

let handler = async (m, { text }) => {
  if (!text) {
    const langs = Object.entries(langList).map(([k, v]) => `${k} = ${v}`).join("\n");
    return m.reply(`*Contoh:*\n${m.cmd} en Halo dunia\n${m.cmd} ja Selamat pagi\n\n*Kode Bahasa:*\n${langs}`);
  }

  const parts = text.split(" ");
  const toLang = parts[0].toLowerCase();
  const content = parts.slice(1).join(" ") || (m.quoted?.body);

  if (!content) return m.reply("❌ Masukkan teks yang ingin diterjemahkan!");
  if (!langList[toLang] && toLang.length !== 2) {
    return m.reply(`❌ Kode bahasa tidak valid!\nContoh: .translate en <teks>`);
  }

  await m.reply("🔄 Menerjemahkan...");
  try {
    const result = await translate(content, toLang);
    return m.reply(
      `🌐 *Translate*\n\n*Bahasa Tujuan:* ${langList[toLang] || toLang}\n\n*Asli:*\n${content}\n\n*Terjemahan:*\n${result}`
    );
  } catch (err) {
    m.reply("❌ Gagal menerjemahkan: " + err.message);
  }
};

handler.command = ["translate", "tr", "tl"];
handler.tags = ["tools"];
handler.help = ["translate <kode> <teks>"];

module.exports = handler;

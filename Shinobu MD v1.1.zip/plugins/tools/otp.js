// plugins/otp.js — dari Ourin MD 3

let handler = async (m, { text }) => {
  const length = parseInt(text) || 6;
  if (length < 4 || length > 12) {
    return m.reply("Panjang OTP harus antara 4-12 digit!");
  }

  const digits = "0123456789";
  let otp = "";
  for (let i = 0; i < length; i++) {
    otp += digits[Math.floor(Math.random() * digits.length)];
  }

  const expire = new Date(Date.now() + 5 * 60 * 1000);
  const teks = `
🔐 *Generate OTP*

Kode OTP: *${otp}*
Panjang: ${length} digit
Berlaku hingga: ${expire.toLocaleTimeString("id-ID")}

⚠ Jangan bagikan kode ini kepada siapapun!`;

  await m.reply(teks);
};

handler.command = ["otp", "genotp"];
handler.tags = ["tools"];
handler.help = ["otp <panjang>"];

module.exports = handler;

const providers = [
  "Telkomsel",
  "Indosat Ooredoo",
  "XL Axiata",
  "Tri",
  "Smartfren",
  "Axis",
  "By.U"
];

function getRandomKartu(maxLen = 12) {
  const raw = providers[Math.floor(Math.random() * providers.length)];
  const name = raw.toUpperCase();

  if (name.length > maxLen) {
    return name.slice(0, maxLen) + "…"; // contoh: INDOSAT OORE...
  }
  return name;
}

let handler = async (m, { sock, text, prefix, command }) => {
  if (!text) {
    return sock.sendMessage(m.chat, { text: `Masukkan Teksnya!\n*Contoh:*\n${prefix + command} hai` }, { quoted: m })
  }

  await sock.sendMessage(m.chat, { react: { text: '🕒', key: m.key } })

  const card = getRandomKartu();
  const timezones = ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"];
  const randomTz = timezones[Math.floor(Math.random() * timezones.length)];

  const jam = new Date().toLocaleTimeString("id-ID", {
    timeZone: randomTz,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });

  const baterai = Math.floor(Math.random() * 100) + 1; // 1–100
  const signal = Math.floor(Math.random() * 4) + 1;   // 1–4

  const res = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(jam)}&messageText=${encodeURIComponent(text)}&carrierName=${encodeURIComponent(card)}&batteryPercentage=${baterai}&signalStrength=${signal}`;

  await sock.sendMessage(m.chat, { image: { url: res } }, { quoted: m });
  
  await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

handler.command = ["iqc", "iphonequote"]
handler.tags = ["tools"]
handler.help = ["iqc <teks>"]

module.exports = handler
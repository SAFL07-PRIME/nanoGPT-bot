const axios = require("axios")
const FormData = require("form-data")
const fs = require("fs")

let handler = async (m, { sock }) => {
  let mime = m.mime || ""
  if (!/image/.test(mime)) return m.reply("Kirim/reply foto dengan caption *.tohd*")

  let qmsg = m.qmsg
  let media = await sock.downloadAndSaveMediaMessage(qmsg)

  try {
    let form = new FormData()
    form.append("apikey", "skyy")
    form.append("image", fs.createReadStream(media))
    
    await m.reply("Memproses HD Image...")

    let { data } = await axios.post(
      "https://api.skyzopedia.web.id/imagecreator/upscale",
      form,
      { headers: form.getHeaders() }
    )

    if (!data || !data.result) throw "Gagal upscale gambar!"

    await sock.sendMessage(m.chat, {
      image: { url: data.result },
      caption: "✨ *HD Image Result*"
    }, { quoted: m })

  } catch (e) {
    m.reply("❌ Gagal memproses gambar.")
  } finally {
    fs.unlinkSync(media)
  }
}

handler.help = ["tohd"]
handler.tags = ["tools"]
handler.command = ["tohd"]

module.exports = handler
// plugins/tools-ipwho.js — IP Lookup & NPM Search dari Ourin MD 3.1

let handler = async (m, { sock, command, args, text }) => {

  // ── IP Lookup ──────────────────────────
  if (command === "ipwho" || command === "ip" || command === "iplookup") {
    const ip = args?.[0];
    if (!ip) return m.reply(`⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n> \`${m.cmd} <ip>\`\n\n> Contoh:\n> \`${m.cmd} 8.8.8.8\``);

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(ip)) return m.reply(`❌ *ꜰᴏʀᴍᴀᴛ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ*\n\n> Contoh: \`8.8.8.8\``);

    await m.react("🕕");

    try {
      const res = await fetch(`https://ipwho.is/${ip}`);
      const data = await res.json();

      if (!data.success) { await m.react("❌"); return m.reply(`❌ *IP tidak ditemukan*\n\n> IP ${ip} tidak valid`); }

      if (data.latitude && data.longitude) {
        await sock.sendMessage(m.chat, {
          location: { degreesLatitude: data.latitude, degreesLongitude: data.longitude },
        }, { quoted: m.verifiedQuoted });
      }

      const txt =
        `🌐 *ɪᴘ ʟᴏᴏᴋᴜᴘ*\n\n` +
        `╭┈┈⬡「 📍 *ʟᴏᴋᴀsɪ* 」\n` +
        `┃ 🔢 IP: ${data.ip}\n` +
        `┃ 🌍 Country: ${data.country} ${data.country_code}\n` +
        `┃ 🏙️ City: ${data.city || "-"}\n` +
        `┃ 📍 Region: ${data.region || "-"}\n` +
        `┃ 🌐 Continent: ${data.continent || "-"}\n` +
        `┃ 📮 Postal: ${data.postal || "-"}\n` +
        `┃ ⏰ Timezone: ${data.timezone?.id || "-"}\n` +
        `╰┈┈┈┈┈┈┈┈⬡\n\n` +
        `╭┈┈⬡「 🔌 *ᴋᴏɴᴇᴋsɪ* 」\n` +
        `┃ 🏢 ISP: ${data.connection?.isp || "-"}\n` +
        `┃ 🌐 ORG: ${data.connection?.org || "-"}\n` +
        `┃ 📡 ASN: ${data.connection?.asn || "-"}\n` +
        `╰┈┈┈┈┈┈┈┈⬡\n\n` +
        `╭┈┈⬡「 🛡️ *sᴇᴄᴜʀɪᴛʏ* 」\n` +
        `┃ 🔒 VPN: ${data.security?.vpn ? "✅ Yes" : "❌ No"}\n` +
        `┃ 🌐 Proxy: ${data.security?.proxy ? "✅ Yes" : "❌ No"}\n` +
        `┃ 🤖 Tor: ${data.security?.tor ? "✅ Yes" : "❌ No"}\n` +
        `╰┈┈┈┈┈┈┈┈⬡`;

      await m.react("✅");
      return m.reply(txt);
    } catch (e) {
      await m.react("☢");
      return m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── NPM Search ─────────────────────────
  if (command === "npm" || command === "npmsearch" || command === "npmjs" || command === "npmfind") {
    if (!text) return m.reply(`⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n> \`${m.cmd} <query>\`\n\n> Contoh:\n> \`${m.cmd} axios\``);

    await m.react("🕕");

    try {
      const res = await fetch(`https://registry.npmjs.com/-/v1/search?text=${encodeURIComponent(text)}&size=10`);
      const data = await res.json();

      if (!data.objects || data.objects.length === 0) {
        await m.react("❌");
        return m.reply(`❌ *Tidak ditemukan*\n\n> Package "${text}" tidak ditemukan`);
      }

      let txt = `📦 *ɴᴘᴍ sᴇᴀʀᴄʜ*\n\n`;
      data.objects.slice(0, 10).forEach((obj, i) => {
        const p = obj.package;
        txt += `*${i + 1}. ${p.name}*\n`;
        txt += `   📝 ${(p.description || "-").slice(0, 80)}\n`;
        txt += `   📌 v${p.version}\n`;
        txt += `   🔗 ${p.links?.npm || ""}\n\n`;
      });

      await m.react("✅");
      return m.reply(txt);
    } catch (e) {
      await m.react("☢");
      return m.reply("❌ Gagal: " + e.message);
    }
  }
};

handler.command = ["ipwho", "ip", "iplookup", "npm", "npmsearch", "npmjs", "npmfind"];
handler.tags = ["tools"];
handler.help = ["ipwho <ip>", "npm <package>"];
module.exports = handler;

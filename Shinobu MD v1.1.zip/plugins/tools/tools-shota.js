// plugins/tools-shota.js — Tools dari Shota Bot MD
const axios = require("axios");
const { downloadContentFromMessage } = require("dekzymarket-cyber");
const FormData = require("form-data");

const API = "https://api.nexray.eu.cc";

async function downloadMedia(m) {
  const qmsg = m.quoted ? m.quoted : m;
  const msg = qmsg.msg || qmsg;
  const type = (msg.mimetype || "").split("/")[0];
  const stream = await downloadContentFromMessage(msg, type);
  let buf = Buffer.from([]);
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk]);
  return buf;
}

let handler = async (m, { sock, command, text, args }) => {

  // ── Cek IP ────────────────────────────
  if (command === "cekip" || command === "ipinfo") {
    const ip = text || "";
    await m.react("🔍");
    try {
      const { data } = await axios.get(
        `https://ipinfo.io/${ip ? ip + "/" : ""}json`,
        { timeout: 10000 }
      );
      return m.reply(
        `🌐 *IP Info*\n\n` +
        `╭┈┈⬡\n` +
        `┃ 🖥 IP: *${data.ip || "-"}*\n` +
        `┃ 🏙 Kota: *${data.city || "-"}*\n` +
        `┃ 🌏 Region: *${data.region || "-"}*\n` +
        `┃ 🚩 Negara: *${data.country || "-"}*\n` +
        `┃ 🏢 ISP: *${data.org || "-"}*\n` +
        `┃ 📍 Lokasi: *${data.loc || "-"}*\n` +
        `┃ 🕐 Timezone: *${data.timezone || "-"}*\n` +
        `╰┈┈⬡`
      );
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── GSM Arena ─────────────────────────
  if (command === "gsmarena" || command === "cekspek") {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} Samsung Galaxy S24`);
    await m.react("📱");

    try {
      const { data } = await axios.get(
        `${API}/search/gsmarena?q=${encodeURIComponent(text)}`,
        { timeout: 20000 }
      );
      const r = data?.result || data?.results || data;
      const device = Array.isArray(r) ? r[0] : r;
      if (!device) return m.reply("❌ Perangkat tidak ditemukan!");

      const spec = device.spec || device.specifications || {};
      const caption =
        `📱 *${device.name || text}*\n\n` +
        `🖥 Display: ${spec.display || device.display || "-"}\n` +
        `⚙️ Chipset: ${spec.chipset || device.chipset || "-"}\n` +
        `💾 RAM: ${spec.ram || device.ram || "-"}\n` +
        `📦 Storage: ${spec.storage || device.storage || "-"}\n` +
        `📷 Kamera: ${spec.camera || device.camera || "-"}\n` +
        `🔋 Baterai: ${spec.battery || device.battery || "-"}\n` +
        `💰 Harga: ${spec.price || device.price || "-"}`;

      if (device.image || device.img) {
        await sock.sendMessage(m.chat, {
          image: { url: device.image || device.img }, caption,
        }, { quoted: m.verifiedQuoted });
      } else {
        await m.reply(caption);
      }
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Error: " + e.message);
    }
  }

  // ── What Music (SongRecognizer) ────────
  if (command === "whatmusic" || command === "ceklagu") {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.includes("audio") && !mime.includes("video"))
      return m.reply("Reply audio/video untuk mengenali lagunya!");

    await m.react("🎵");
    await m.reply("🎵 Mengenali lagu...");

    try {
      const buf = await downloadMedia(m);
      const form = new FormData();
      form.append("audio", buf, "audio.mp3");

      const { data } = await axios.post(
        `${API}/tools/shazam`,
        form,
        { headers: form.getHeaders(), timeout: 30000 }
      );

      const r = data?.result || data;
      return m.reply(
        `🎵 *Lagu Terdeteksi!*\n\n` +
        `🎤 Judul: *${r.title || "-"}*\n` +
        `👤 Artis: *${r.artist || r.subtitle || "-"}*\n` +
        `💿 Album: *${r.album || "-"}*\n` +
        `📅 Tahun: *${r.year || "-"}*\n` +
        `🔗 ${r.url || ""}`
      );
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Kompres Gambar ─────────────────────
  if (command === "kompres" || command === "compress") {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.startsWith("image/"))
      return m.reply("Reply atau kirim gambar untuk dikompres!");

    await m.react("⏳");
    try {
      const buf = await downloadMedia(m);
      const form = new FormData();
      form.append("image", buf, "image.jpg");

      const { data } = await axios.post(
        `${API}/tools/compress`,
        form,
        { headers: form.getHeaders(), responseType: "arraybuffer", timeout: 30000 }
      );

      await sock.sendMessage(m.chat, {
        image: Buffer.from(data),
        caption: "✅ *Gambar berhasil dikompres!*",
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── OCR (baca teks dari gambar) ────────
  if (command === "ocr" || command === "readimg") {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.startsWith("image/"))
      return m.reply("Reply gambar yang ingin dibaca teksnya!");

    await m.react("⏳");
    await m.reply("🔍 Membaca teks dari gambar...");

    try {
      const buf = await downloadMedia(m);
      const form = new FormData();
      form.append("image", buf, "image.jpg");

      const { data } = await axios.post(
        `${API}/tools/ocr`,
        form,
        { headers: form.getHeaders(), timeout: 30000 }
      );

      const text = data?.result || data?.text || data?.data;
      if (!text) return m.reply("❌ Tidak ada teks terdeteksi di gambar!");

      await m.reply(`📝 *Teks dari Gambar*\n\n${text}`);
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Remove BG ─────────────────────────
  if (command === "removebg" || command === "rmbg") {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.startsWith("image/"))
      return m.reply("Reply atau kirim gambar untuk hapus background!");

    await m.react("⏳");
    await m.reply("✂️ Menghapus background...");

    try {
      const buf = await downloadMedia(m);
      const form = new FormData();
      form.append("image_file", buf, "image.png");
      form.append("size", "auto");

      const { data } = await axios.post(
        "https://api.remove.bg/v1.0/removebg",
        form,
        {
          headers: {
            ...form.getHeaders(),
            "X-Api-Key": "rGVJ7GUqfSGqNZH7GGvPsXMm",
          },
          responseType: "arraybuffer",
          timeout: 30000,
        }
      );

      await sock.sendMessage(m.chat, {
        image: Buffer.from(data),
        caption: "✅ *Background berhasil dihapus!*",
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      // Fallback API
      try {
        const buf = await downloadMedia(m);
        const base64 = buf.toString("base64");
        const { data } = await axios.post(
          `${API}/tools/removebg`,
          { image: base64 },
          { headers: { "Content-Type": "application/json" }, responseType: "arraybuffer", timeout: 30000 }
        );
        await sock.sendMessage(m.chat, {
          image: Buffer.from(data),
          caption: "✅ *Background berhasil dihapus!*",
        }, { quoted: m.verifiedQuoted });
        await m.react("✅");
      } catch (e2) {
        await m.react("❌");
        m.reply("❌ Gagal hapus background: " + e2.message);
      }
    }
  }
};

handler.command = [
  "cekip", "ipinfo",
  "gsmarena", "cekspek",
  "whatmusic", "ceklagu",
  "kompres", "compress",
  "ocr", "readimg",
  "removebg", "rmbg",
];
handler.tags = ["tools"];
handler.help = [
  "cekip [ip]",
  "gsmarena <nama hp>",
  "whatmusic [reply audio]",
  "kompres [reply gambar]",
  "ocr [reply gambar]",
  "removebg [reply gambar]",
];
module.exports = handler;

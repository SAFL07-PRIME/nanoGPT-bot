// plugins/menu.js — Auto Register All Plugins
const os = require("os");
const { performance } = require("perf_hooks");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

// ── Pakai dekzymarket-cyber baileys ───────
let prepareWAMessageMedia;
try {
  prepareWAMessageMedia = require("dekzymarket-cyber").prepareWAMessageMedia;
} catch {}

function toMonoUpperBold(t) {
  const mp = {A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭",0:"𝟬",1:"𝟭",2:"𝟮",3:"𝟯",4:"𝟰",5:"𝟱",6:"𝟲",7:"𝟳",8:"𝟴",9:"𝟵"," ":" "};
  return t.toUpperCase().split("").map(c => mp[c]||c).join("");
}

function getGreeting() {
  const h = parseInt(new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta", hour: "numeric", hour12: false
  }));
  if (h >= 0  && h < 5)  return "🌙 Selamat Malam";
  if (h >= 5  && h < 11) return "🌤 Selamat Pagi";
  if (h >= 11 && h < 15) return "☀️ Selamat Siang";
  if (h >= 15 && h < 18) return "🌥 Selamat Sore";
  return "🌙 Selamat Malam";
}

function fmtUptime(s) {
  const d=Math.floor(s/86400),h=Math.floor((s%86400)/3600),mn=Math.floor((s%3600)/60),sc=Math.floor(s%60);
  return d?`${d}d ${h}h ${mn}m`:h?`${h}h ${mn}m ${sc}s`:`${mn}m ${sc}s`;
}

const CAT_EMOJI = {
  main:"✦",owner:"♛",group:"✿",download:"⬇",tools:"⚙",ai:"◈",
  user:"◉",game:"◈",fun:"❋",search:"⊕",sticker:"◆",religi:"☽",
  info:"◎",convert:"↻",store:"◈",pterodactyl:"⬡",random:"◈",
  rpg:"⚔",maker:"🎨",
};
const CAT_ORDER = ["main","owner","group","fun","game","rpg","maker","download","tools","ai","search","sticker","religi","info","user","convert","store","pterodactyl","random"];

// ===== FUNGSI SCAN PLUGIN OTOMATIS =====
function scanAllPlugins() {
  const toArr = v => !v ? [] : (Array.isArray(v) ? v : [v]);
  let categories = {};
  
  // 1. Scan dari global.plugins (yang sudah di-load)
  if (global.plugins) {
    for (let file in global.plugins) {
      const plug = global.plugins[file];
      if (!plug) continue;
      
      const tags = toArr(plug.tags);
      const cmds = plug.help ? toArr(plug.help) : toArr(plug.command);
      
      // Jika tidak ada tags, beri default
      if (!tags.length && cmds.length) {
        // Coba deteksi dari path
        let defaultTag = 'tools';
        if (file.includes('owner')) defaultTag = 'owner';
        else if (file.includes('group')) defaultTag = 'group';
        else if (file.includes('ai')) defaultTag = 'ai';
        else if (file.includes('download')) defaultTag = 'download';
        else if (file.includes('fun')) defaultTag = 'fun';
        else if (file.includes('game')) defaultTag = 'game';
        else if (file.includes('rpg')) defaultTag = 'rpg';
        else if (file.includes('maker')) defaultTag = 'maker';
        else if (file.includes('tools')) defaultTag = 'tools';
        
        tags.push(defaultTag);
      }
      
      if (!tags.length || !cmds.length) continue;
      
      for (const rawTag of tags) {
        const key = String(rawTag).toLowerCase();
        if (!categories[key]) {
          categories[key] = { 
            cat: key, 
            emoji: CAT_EMOJI[key] || "◈", 
            cmds: [],
            plugins: []
          };
        }
        cmds.forEach(c => {
          const cmd = c.toString().split(" ")[0];
          if (cmd && !categories[key].cmds.includes(cmd)) {
            categories[key].cmds.push(cmd);
            categories[key].plugins.push(file);
          }
        });
      }
    }
  }
  
  // 2. Scan dari folder plugins (untuk plugin yang belum di-load)
  try {
    const pluginsDir = path.join(process.cwd(), 'plugins');
    if (fs.existsSync(pluginsDir)) {
      scanPluginFolder(pluginsDir, categories);
    }
  } catch (e) {
    console.log('Scan folder plugins error:', e.message);
  }
  
  return categories;
}

// ===== SCAN FOLDER PLUGINS =====
function scanPluginFolder(dir, categories) {
  const files = fs.readdirSync(dir);
  
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      scanPluginFolder(filePath, categories);
    } else if (file.endsWith('.js') && !file.includes('menu')) {
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        
        // Extract command
        let cmds = [];
        const cmdMatch = content.match(/handler\.command\s*=\s*\[([^\]]+)\]/);
        if (cmdMatch) {
          cmds = cmdMatch[1].split(',').map(c => c.trim().replace(/['"]/g, ''));
        }
        
        // Extract tags
        let tags = [];
        const tagsMatch = content.match(/handler\.tags\s*=\s*\[([^\]]+)\]/);
        if (tagsMatch) {
          tags = tagsMatch[1].split(',').map(c => c.trim().replace(/['"]/g, ''));
        }
        
        // Extract help
        let help = [];
        const helpMatch = content.match(/handler\.help\s*=\s*\[([^\]]+)\]/);
        if (helpMatch) {
          help = helpMatch[1].split(',').map(c => c.trim().replace(/['"]/g, ''));
        }
        
        const finalCmds = help.length > 0 ? help : cmds;
        
        if (!tags.length && finalCmds.length) {
          // Deteksi dari path folder
          let defaultTag = 'tools';
          const folderName = path.basename(path.dirname(filePath));
          if (['owner', 'group', 'ai', 'download', 'fun', 'game', 'rpg', 'maker', 'tools'].includes(folderName)) {
            defaultTag = folderName;
          }
          tags.push(defaultTag);
        }
        
        if (tags.length && finalCmds.length) {
          for (const rawTag of tags) {
            const key = String(rawTag).toLowerCase();
            if (!categories[key]) {
              categories[key] = { 
                cat: key, 
                emoji: CAT_EMOJI[key] || "◈", 
                cmds: [],
                plugins: []
              };
            }
            finalCmds.forEach(c => {
              const cmd = c.toString().split(" ")[0];
              if (cmd && !categories[key].cmds.includes(cmd)) {
                categories[key].cmds.push(cmd);
                categories[key].plugins.push(file);
              }
            });
          }
        }
      } catch (e) {
        // Skip file yang error
      }
    }
  }
}

let handler = async (m, { sock }) => {
  // ===== SCAN SEMUA PLUGIN =====
  let categories = scanAllPlugins();
  
  // Sort categories
  const sorted = [
    ...CAT_ORDER.filter(k=>categories[k]).map(k=>categories[k]),
    ...Object.keys(categories).filter(k=>!CAT_ORDER.includes(k)).sort().map(k=>categories[k]),
  ];

  // ── Build menu string ────────────────
  let menuStr = "";
  sorted.forEach(({ cat, emoji, cmds }) => {
    menuStr += `╭─☰ ${toMonoUpperBold(cat)}\n`;
    cmds.sort().forEach(cmd => { menuStr += `> ${global.prefix}${cmd}\n`; });
    menuStr += "╰─⬣\n\n";
  });

  // ── single_select rows ───────────────
  const rows = sorted.map(({ cat, emoji, cmds }) => ({
    title: `${emoji} ${toMonoUpperBold(cat)}`,
    description: `(${cmds.length}) Perintah`,
    id: `${global.prefix}cat_${cat}`,
  }));

  const totalCmd = sorted.reduce((a,c)=>a+c.cmds.length,0);
  const uptime   = fmtUptime(process.uptime());
  const totalMem = (os.totalmem()/1024/1024/1024).toFixed(2);
  const usedMem  = ((os.totalmem()-os.freemem())/1024/1024).toFixed(0);
  const user     = global.db?.users?.[m.sender] || {};
  const isPrem   = m.isPremium;
  const greeting = getGreeting();
  const readmore = String.fromCharCode(8206).repeat(4001);
  const energiMax = isPrem?(global.energiPremium||500):(global.energiDefault||50);

  const bodyText =
`👋 *Hello ${m.pushName||"Brother"}*

${greeting}! Selamat menggunakan *${global.botname}*

╭┈┈⫹⫺ 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢 ⫹⫺┈┈╮
│ ◈ *Nama Bot*   : *${global.botname}*
│ ◈ *Versi*      : *v${global.versibot}*
│ ◈ *Developer*  : *${global.ownername}*
│ ◈ *Prefix*     : \`${global.prefix}\`
│ ◈ *Mode*       : *${sock.public?"Public":"Self"}*
│ ◈ *Uptime*     : *${uptime}*
│ ◈ *RAM*        : *${usedMem} MB / ${totalMem} GB*
│ ◈ *Total Cmd*  : *${totalCmd} command*
╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈

╭┈┈⫹⫺ 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢 ⫹⫺┈┈╮
│ ◈ *Nama*    : *${m.pushName||"-"}*
│ ◈ *Role*    : *${m.isOwner?"👑 Owner":isPrem?"💎 Premium":"👤 User"}*
│ ◈ *Energi*  : *${user.energi??energiMax}/${energiMax}*
│ ◈ *Koin*    : *${user.koin||0}*
│ ◈ *XP*      : *${user.exp||0}*
│ ◈ *Daftar*  : *${user.registered?"Sudah":"Belum"}*
╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈

${readmore}${menuStr}`;

  // ── Ambil thumbnail buffer ───────────
  let thumbBuf = null;
  try {
    const r = await axios.get(global.thumbnail, {responseType:"arraybuffer",timeout:8000});
    thumbBuf = Buffer.from(r.data);
  } catch {}

  // ── Build nativeFlowMessage ──────────
  const nativeFlow = {
    messageParamsJson: JSON.stringify({
      limited_time_offer: {
        text: greeting,
        url: "Hai",
        copy_code: "Dibuat oleh " + global.ownername,
        expiration_time: Date.now() + 1000000,
      },
      bottom_sheet: {
        in_thread_buttons_limit: 2,
        divider_indices: [1,2,3,4,5,999],
        list_title: "Silahkan pilih menu yang kamu inginkan",
        button_title: "📋 Selengkapnya",
      },
    }),
    buttons: [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify({
          title: "🌲 Lihat Semua Menu",
          sections: [{ title: "Pilih kategori menu", rows }],
        }),
      },
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 Lihat Kategori",
          url: global.linkGrup||"https://chat.whatsapp.com",
          merchant_url: global.linkGrup||"https://chat.whatsapp.com",
        }),
      },
      {
        name: "cta_call",
        buttonParamsJson: JSON.stringify({
          display_text: "🦅 Owner Dari Bot ini",
          phone_number: global.owner,
        }),
      },
    ],
  };

  const contextInfo = {
    isForwarded: true,
    forwardingScore: 9,
    participant: "0@s.whatsapp.net",
    quotedMessage: { conversation: `${global.botname}` },
    mentionedJid: [`${m.sender}`],
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idChannel||"120363427915199733@newsletter",
      newsletterName: global.botname,
      serverMessageId: 127,
    },
  };

  // ── Coba kirim dengan image header ───
  let sent = false;

  if (thumbBuf && prepareWAMessageMedia) {
    try {
      const media = await prepareWAMessageMedia(
        { image: thumbBuf },
        { upload: sock.waUploadToServer }
      );
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: {
                title: "", subtitle: "",
                hasMediaAttachment: true,
                imageMessage: media.imageMessage,
              },
              body: { text: bodyText },
              footer: { text: "Pilih tombol dibawah untuk info lebih lanjut" },
              contextInfo,
              nativeFlowMessage: nativeFlow,
            },
          },
        },
      }, {});
      sent = true;
    } catch (e) {
      console.log("[Menu] Image header gagal:", e.message);
    }
  }

  // ── Fallback: kirim tanpa image header ─
  if (!sent) {
    try {
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: {
                title: global.botname,
                subtitle: `v${global.versibot}`,
                hasMediaAttachment: false,
              },
              body: { text: bodyText },
              footer: { text: "Pilih tombol dibawah untuk info lebih lanjut" },
              contextInfo,
              nativeFlowMessage: nativeFlow,
            },
          },
        },
      }, {});
      sent = true;
    } catch (e) {
      console.log("[Menu] Interactive gagal:", e.message);
    }
  }

  // ── Fallback final: teks biasa + foto ─
  if (!sent) {
    const fallback =
      `╭─☰ ${toMonoUpperBold(global.botname)}\n` +
      `> Mode   : ${sock.public?"Public":"Self"}\n` +
      `> Uptime : ${uptime}\n` +
      `> RAM    : ${usedMem} MB\n` +
      `> Prefix : ${global.prefix}\n` +
      `> Role   : ${m.isOwner?"🔥 Owner":isPrem?"👑 Premium":"😊 User"}\n` +
      `╰─⬣\n\n${menuStr}`;

    if (thumbBuf) {
      await sock.sendMessage(m.chat, {
        image: thumbBuf, caption: fallback,
      }, { quoted: m.verifiedQuoted });
    } else {
      await sock.sendMessage(m.chat, { text: fallback }, { quoted: m.verifiedQuoted });
    }
  }
};

handler.command = ["menu","help","?","m"];
handler.tags = ["main"];
handler.help = ["menu"];
module.exports = handler;

// plugins/ping.js — Shinobu MD V1
const { performance } = require("perf_hooks");

let handler = async (m, { sock }) => {
  const start = performance.now();
  const msg = await sock.sendMessage(m.chat, {
    text: "⏳ *Pinging...*",
  }, { quoted: m });
  const end = performance.now();
  const latency = (end - start).toFixed(2);

  const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
  const usedMem = ((os.totalmem() - os.freemem()) / 1024 / 1024).toFixed(0);

  await sock.sendMessage(m.chat, {
    text:
`╭━━━━◈ 🏓 𝗣𝗢𝗡𝗚! ◈━━━━╮
┃  ⌬ Latency › *${latency} ms*
┃  ⌬ Status  › *Online ✅*
┃  ⌬ Uptime  › *${global.runtime(process.uptime())}*
┃  ⌬ RAM     › *${usedMem} MB*
┃  ⌬ Bot     › *${global.botname}*
╰━━━━━━━━━━━━━━━━━━━━━⬣`,
    edit: msg.key,
  });

  await m.react("✅");
};

const os = require("os");
handler.command = ["ping", "speed", "p"];
handler.tags = ["main"];
handler.help = ["ping"];
module.exports = handler;

// plugins/game-family100.js — dari Ourin MD 3

if (!global.f100Sessions) global.f100Sessions = {};

const SOAL = [
  { q: "Sebutkan warna pelangi!", answers: ["merah","jingga","kuning","hijau","biru","nila","ungu"], bonus: ["orange","violet"] },
  { q: "Sebutkan hari dalam seminggu!", answers: ["senin","selasa","rabu","kamis","jumat","sabtu","minggu"] },
  { q: "Sebutkan bulan dalam setahun!", answers: ["januari","februari","maret","april","mei","juni","juli","agustus","september","oktober","november","desember"] },
  { q: "Sebutkan planet di tata surya!", answers: ["merkurius","venus","bumi","mars","jupiter","saturnus","uranus","neptunus"] },
  { q: "Sebutkan nama hewan yang hidup di laut!", answers: ["ikan","lumba-lumba","paus","hiu","gurita","cumi","kepiting","udang","lobster","penyu"] },
  { q: "Sebutkan nama buah tropis!", answers: ["mangga","durian","rambutan","salak","nangka","jambu","pepaya","pisang","semangka","melon"] },
  { q: "Sebutkan olahraga populer!", answers: ["sepakbola","basket","voli","bulu tangkis","renang","tenis","tinju","lari","bersepeda","senam"] },
  { q: "Sebutkan alat musik!", answers: ["gitar","piano","biola","drum","suling","kecapi","angklung","gamelan","terompet","harmonika"] },
  { q: "Sebutkan nama presiden Indonesia!", answers: ["soekarno","soeharto","habibie","gus dur","megawati","sby","jokowi","prabowo"] },
  { q: "Sebutkan nama provinsi di Pulau Jawa!", answers: ["banten","dki jakarta","jawa barat","jawa tengah","diy","jawa timur"] },
];

let handler = async (m, { sock, command }) => {
  const chat = m.chat;

  if (command === "family100" || command === "f100") {
    if (global.f100Sessions[chat]) {
      const s = global.f100Sessions[chat];
      const found = s.answers.filter(a => s.found.includes(a)).length;
      return m.reply(
        `🎮 Ada game Family 100 berjalan!\n\n` +
        `❓ *${s.question}*\n\n` +
        `✅ Ditemukan: ${found}/${s.answers.length}\n` +
        `🔤 ${s.answers.map(a => s.found.includes(a) ? `*${a}*` : "___").join(", ")}\n\n` +
        `⏱ Ketik jawaban langsung!\n*.stopf100* untuk berhenti.`
      );
    }

    const soal = SOAL[Math.floor(Math.random() * SOAL.length)];
    global.f100Sessions[chat] = {
      question: soal.q,
      answers: soal.answers,
      bonus: soal.bonus || [],
      found: [],
      scores: {},
      startTime: Date.now(),
    };

    // Auto end setelah 3 menit
    setTimeout(() => {
      const s = global.f100Sessions[chat];
      if (!s) return;
      const recap = Object.entries(s.scores).sort((a,b)=>b[1]-a[1]);
      let txt = `⏰ *Waktu Habis!*\n\nJawaban yang benar:\n${s.answers.join(", ")}\n\n`;
      if (recap.length) {
        txt += `🏆 *Skor Akhir:*\n`;
        recap.forEach(([jid, score], i) => {
          txt += `${i+1}. @${jid.split("@")[0]} — *${score} poin*\n`;
        });
      }
      delete global.f100Sessions[chat];
      sock.sendMessage(chat, { text: txt, mentions: recap.map(r => r[0]) });
    }, 3 * 60 * 1000);

    return m.reply(
      `🎮 *FAMILY 100 DIMULAI!*\n\n` +
      `❓ *${soal.q}*\n\n` +
      `Cari *${soal.answers.length}* jawaban!\n` +
      `Ketik jawaban langsung!\n` +
      `⏱ Waktu: 3 menit\n*.stopf100* untuk berhenti.`
    );
  }

  if (command === "stopf100") {
    if (!global.f100Sessions[chat]) return m.reply("❌ Tidak ada game yang berjalan!");
    const s = global.f100Sessions[chat];
    const recap = Object.entries(s.scores).sort((a,b)=>b[1]-a[1]);
    let txt = `🛑 *Game Dihentikan!*\n\nJawaban:\n${s.answers.join(", ")}\n\n`;
    if (recap.length) {
      txt += `🏆 *Skor:*\n`;
      recap.forEach(([jid, score], i) => {
        txt += `${i+1}. @${jid.split("@")[0]} — *${score} poin*\n`;
      });
    }
    delete global.f100Sessions[chat];
    return sock.sendMessage(chat, { text: txt, mentions: recap.map(r => r[0]) }, { quoted: m });
  }
};

handler.all = async function (m, { sock }) {
  const s = global.f100Sessions?.[m.chat];
  if (!s) return;
  if (!m.body) return;

  const jawaban = m.body.trim().toLowerCase();
  if (jawaban.startsWith(".")) return;

  if (s.answers.includes(jawaban) && !s.found.includes(jawaban)) {
    s.found.push(jawaban);
    if (!s.scores[m.sender]) s.scores[m.sender] = 0;
    s.scores[m.sender] += 10;

    await m.react("✅");

    if (s.found.length === s.answers.length) {
      const recap = Object.entries(s.scores).sort((a,b)=>b[1]-a[1]);
      let txt = `🎉 *SEMUA JAWABAN DITEMUKAN!*\n\nJawaban:\n${s.answers.join(", ")}\n\n🏆 *Skor Akhir:*\n`;
      recap.forEach(([jid, score], i) => {
        txt += `${i+1}. @${jid.split("@")[0]} — *${score} poin*\n`;
      });
      delete global.f100Sessions[m.chat];
      return sock.sendMessage(m.chat, { text: txt, mentions: recap.map(r => r[0]) });
    }

    const found = s.found.length;
    const total = s.answers.length;
    return sock.sendMessage(m.chat, {
      text: `✅ *${jawaban.toUpperCase()}* benar! +10 poin\n\n${found}/${total} terjawab\n🔤 ${s.answers.map(a => s.found.includes(a) ? `*${a}*` : "___").join(", ")}`,
      mentions: [m.sender],
    });
  }
};

handler.command = ["family100", "f100", "stopf100"];
handler.tags = ["game"];
handler.help = ["family100", "stopf100"];
handler.group = true;
module.exports = handler;

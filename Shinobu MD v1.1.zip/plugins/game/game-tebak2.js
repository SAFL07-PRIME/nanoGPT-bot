// plugins/game-tebak2.js — Game Tebak tambahan dari Ourin MD 3.1 (data inline)

if (!global.tebak2Session) global.tebak2Session = {};

const NEGARA = [
  { soal: "Negara dengan ibukota Jakarta", jawaban: "indonesia" },
  { soal: "Negara dengan ibukota Tokyo", jawaban: "jepang" },
  { soal: "Negara dengan ibukota Paris", jawaban: "prancis" },
  { soal: "Negara dengan ibukota Berlin", jawaban: "jerman" },
  { soal: "Negara dengan ibukota London", jawaban: "inggris" },
  { soal: "Negara dengan ibukota Beijing", jawaban: "china" },
  { soal: "Negara dengan ibukota Seoul", jawaban: "korea selatan" },
  { soal: "Negara dengan ibukota Washington DC", jawaban: "amerika serikat" },
  { soal: "Negara dengan ibukota Bangkok", jawaban: "thailand" },
  { soal: "Negara dengan ibukota Kuala Lumpur", jawaban: "malaysia" },
  { soal: "Negara dengan ibukota Manila", jawaban: "filipina" },
  { soal: "Negara dengan ibukota Hanoi", jawaban: "vietnam" },
  { soal: "Negara dengan ibukota Singapura", jawaban: "singapura" },
  { soal: "Negara dengan ibukota Canberra", jawaban: "australia" },
  { soal: "Negara dengan ibukota Roma", jawaban: "italia" },
  { soal: "Negara dengan ibukota Madrid", jawaban: "spanyol" },
  { soal: "Negara dengan ibukota Moskow", jawaban: "rusia" },
  { soal: "Negara dengan ibukota Kairo", jawaban: "mesir" },
  { soal: "Negara dengan ibukota Ottawa", jawaban: "kanada" },
  { soal: "Negara dengan ibukota Brasilia", jawaban: "brazil" },
];

const HEWAN = [
  { soal: "Hewan berbelalai panjang, telinga besar 🐘", jawaban: "gajah" },
  { soal: "Hewan raja hutan, punya surai 🦁", jawaban: "singa" },
  { soal: "Hewan dengan leher panjang banget 🦒", jawaban: "jerapah" },
  { soal: "Hewan loreng hitam putih kayak baju polisi 🦓", jawaban: "zebra" },
  { soal: "Hewan suka berenang, hidup di air dan darat 🐸", jawaban: "katak" },
  { soal: "Hewan berkantung dari Australia 🦘", jawaban: "kanguru" },
  { soal: "Hewan mengeong, suka tikus 🐱", jawaban: "kucing" },
  { soal: "Hewan menggonggong, sahabat manusia 🐶", jawaban: "anjing" },
  { soal: "Hewan lambat tapi punya cangkang keras 🐢", jawaban: "kura-kura" },
  { soal: "Hewan terbesar di laut 🐋", jawaban: "paus" },
  { soal: "Hewan suka makan pisang, mirip manusia 🐵", jawaban: "monyet" },
  { soal: "Hewan berbulu hitam putih dari China 🐼", jawaban: "panda" },
  { soal: "Hewan terbang malam, mata tajam 🦉", jawaban: "burung hantu" },
  { soal: "Hewan paling cepat lari di darat 🐆", jawaban: "cheetah" },
  { soal: "Hewan berduri, suka menggulung badan 🦔", jawaban: "landak" },
];

function shuffle(word) {
  const arr = word.split("");
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.join("");
}

const KATA_SUSUN = [
  "indonesia", "komputer", "matahari", "kemerdekaan", "pendidikan",
  "teknologi", "lingkungan", "kesehatan", "olahraga", "kebudayaan",
  "persahabatan", "kebahagiaan", "pengetahuan", "kemandirian", "kreativitas",
];

let handler = async (m, { sock, command }) => {
  const chat = m.chat;

  if (command === "tebaknegara" || command === "tn") {
    if (global.tebak2Session[chat]) return m.reply(`🎮 Game masih berjalan!\n*.nyerah2* untuk menyerah.`);
    const data = NEGARA[Math.floor(Math.random() * NEGARA.length)];
    global.tebak2Session[chat] = { type: "tebaknegara", jawaban: data.jawaban, timer: setTimeout(() => {
      if (global.tebak2Session[chat]) {
        sock.sendMessage(chat, { text: `⏰ Waktu habis! Jawabannya: *${data.jawaban.toUpperCase()}*` }).catch(() => {});
        delete global.tebak2Session[chat];
      }
    }, 5 * 60000) };
    return m.reply(`🌍 *TEBAK NEGARA*\n\n${data.soal}\n\n⏰ Waktu: 5 menit\n*.nyerah2* kalau buntu`);
  }

  if (command === "tebakhewan" || command === "th") {
    if (global.tebak2Session[chat]) return m.reply(`🎮 Game masih berjalan!\n*.nyerah2* untuk menyerah.`);
    const data = HEWAN[Math.floor(Math.random() * HEWAN.length)];
    global.tebak2Session[chat] = { type: "tebakhewan", jawaban: data.jawaban, timer: setTimeout(() => {
      if (global.tebak2Session[chat]) {
        sock.sendMessage(chat, { text: `⏰ Waktu habis! Jawabannya: *${data.jawaban.toUpperCase()}*` }).catch(() => {});
        delete global.tebak2Session[chat];
      }
    }, 5 * 60000) };
    return m.reply(`🐾 *TEBAK HEWAN*\n\n${data.soal}\n\n⏰ Waktu: 5 menit\n*.nyerah2* kalau buntu`);
  }

  if (command === "susunkata" || command === "susun" || command === "scramble") {
    if (global.tebak2Session[chat]) return m.reply(`🎮 Game masih berjalan!\n*.nyerah2* untuk menyerah.`);
    const kata = KATA_SUSUN[Math.floor(Math.random() * KATA_SUSUN.length)];
    let acak = shuffle(kata);
    while (acak === kata) acak = shuffle(kata);
    global.tebak2Session[chat] = { type: "susunkata", jawaban: kata, timer: setTimeout(() => {
      if (global.tebak2Session[chat]) {
        sock.sendMessage(chat, { text: `⏰ Waktu habis! Jawabannya: *${kata.toUpperCase()}*` }).catch(() => {});
        delete global.tebak2Session[chat];
      }
    }, 5 * 60000) };
    return m.reply(`🔠 *SUSUN KATA*\n\nSusun huruf berikut jadi kata yang benar:\n\n*${acak.toUpperCase()}*\n\n⏰ Waktu: 5 menit\n*.nyerah2* kalau buntu`);
  }

  if (command === "nyerah2") {
    const s = global.tebak2Session[chat];
    if (!s) return m.reply("❌ Tidak ada game yang berjalan!");
    clearTimeout(s.timer);
    const jawaban = s.jawaban;
    delete global.tebak2Session[chat];
    await m.react("🏳️");
    return m.reply(`🏳️ Kamu menyerah! Jawabannya: *${jawaban.toUpperCase()}*`);
  }
};

handler.all = async function (m, { sock }) {
  const s = global.tebak2Session?.[m.chat];
  if (!s || !m.body || m.body.startsWith(global.prefix)) return;

  const jawaban = m.body.trim().toLowerCase();
  if (jawaban === s.jawaban) {
    clearTimeout(s.timer);
    delete global.tebak2Session[m.chat];
    await m.react("✅");
    return sock.sendMessage(m.chat, {
      text: `✅ *BENAR!* @${m.sender.split("@")[0]} menjawab dengan tepat!\n\nJawaban: *${jawaban.toUpperCase()}* 🎉`,
      mentions: [m.sender],
    }, { quoted: m });
  }
};

handler.command = ["tebaknegara", "tn", "tebakhewan", "th", "susunkata", "susun", "scramble", "nyerah2"];
handler.tags = ["game"];
handler.help = ["tebaknegara", "tebakhewan", "susunkata", "nyerah2"];
module.exports = handler;

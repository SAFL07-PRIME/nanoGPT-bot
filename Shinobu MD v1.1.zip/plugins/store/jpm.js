let handler = async (m, { sock, text, command }) => {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms))

  if (!global.db.settings) global.db.settings = {}
  if (!global.db.settings.bljpm) global.db.settings.bljpm = []

  switch (command) {

    // =========================
    // JPM (FORWARD ALL GROUP)
    // =========================
    case "jpm":
    case "jasher":
    case "jaser": {
      if (!m.quoted)
        return m.reply(`Reply pesan dengan ketik .jpm`)

      const message = m.quoted.fakeObj

      let allGroups = await sock.groupFetchAllParticipating()

      const groupIds = Object.values(allGroups)
        .filter(i => !i.isCommunity && !i.announce && !i.isCommunityAnnounce)
        .map(i => i.id)

      let success = 0
      let fail = 0
      let bl = 0

      await m.reply(`🚀 Memulai forward pesan ke ${groupIds.length} grup`)

      for (const id of groupIds) {

        if (global.db.settings.bljpm.find(g => g.id === id)) {
          bl++
          continue
        }

        try {
          await sock.sendMessage(id, {
            forward: message,
            force: true
          })

          success++
        } catch (e) {
          fail++
          console.error("Gagal ke:", id)
        }

        await sleep(5000)
      }

      return m.reply(`✅ *Forward Pesan Selesai*
- Berhasil: ${success}
- Gagal: ${fail}
- Blacklist: ${bl}`)
    }

    case "bljpm": {
      let groups = await sock.groupFetchAllParticipating()

      const rows = Object.values(groups)
        .filter(g => !global.db.settings.bljpm.find(x => x.id === g.id))
        .map(g => ({
          title: g.subject,
          description: "Tambah ke blacklist",
          id: `.addbljpm ${g.id}`
        }))

      return sock.sendMessage(m.chat, {
        text: "\nPilih grup untuk blacklist JPM\n",
        viewOnce: true,
        buttons: [{
          buttonId: "select_gc",
          buttonText: { displayText: "Pilih Grup" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "BL JPM",
              sections: [{ title: "Daftar Grup", rows }]
            })
          }
        }]
      }, { quoted: m })
    }

    case "addbljpm": {
      let meta = await sock.groupMetadata(text)

      global.db.settings.bljpm.push({
        groupName: meta.subject,
        id: text
      })

      return m.reply(`✅ Grup *${meta.subject}* masuk blacklist`)
    }

    case "delbljpm": {
      if (global.db.settings.bljpm.length === 0)
        return m.reply("Blacklist kosong!")

      const rows = global.db.settings.bljpm.map(g => ({
        title: g.groupName,
        description: "Hapus dari blacklist",
        id: `.delbljpm-confirm ${g.id}`
      }))

      return sock.sendMessage(m.chat, {
        text: "\nPilih grup yang ingin dihapus dari blacklist\n",
        viewOnce: true,
        buttons: [{
          buttonId: "select_gc",
          buttonText: { displayText: "Pilih Grup" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "DEL BL JPM",
              sections: [{ title: "Blacklist Grup", rows }]
            })
          }
        }]
      }, { quoted: m })
    }

    case "delbljpm-confirm": {
      global.db.settings.bljpm =
        global.db.settings.bljpm.filter(g => g.id !== text)

      return m.reply("✅ Berhasil dihapus dari blacklist")
    }

  }
}

handler.command = [
  "jpm","jasher","jaser",
  "bljpm","addbljpm","delbljpm","delbljpm-confirm"
]

handler.tags = ["store"]
handler.help = [
  "jpm (reply pesan)",
  "bljpm",
  "delbljpm"
]

handler.owner = true
module.exports = handler
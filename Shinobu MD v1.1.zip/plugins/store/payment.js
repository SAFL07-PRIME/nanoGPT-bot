let handler = async (m, { sock, command }) => {

  let wallet = {}

  if (command === "dana") {
    wallet = { name: "DANA", key: global.dana }
  } else if (command === "ovo") {
    wallet = { name: "OVO", key: global.ovo }
  } else if (command === "gopay") {
    wallet = { name: "GoPay", key: global.gopay }
  } else if (command === "qris" || command === "payment" || command === "pay") {
    if (!global.qris) return m.reply("❌ QRIS belum disetel.")
    
    return sock.sendMessage(m.chat, {
      image: { url: global.qris },
      caption: `
- Dana: ${global.dana}\n- OVO: ${global.ovo}\n- Gopay: ${global.gopay}

*Penting!!*
Wajib kirimkan bukti Transfer, Demi keamanan bersama.`
    }, { quoted: m })
  }

  if (!wallet.name || !wallet.key) {
    return m.reply("❌ E-wallet belum disetel.")
  }

  await sock.relayMessage(
    m.chat,
    {
      interactiveMessage: {
        body: { text: "" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_key_info",
              buttonParamsJson: JSON.stringify({
                currency: "IDR",
                total_amount: { value: 0, offset: 100 },
                reference_id: `${wallet.name}-${Date.now()}`,
                type: "digital-goods",
                order: {
                  status: "pending",
                  subtotal: { value: 0, offset: 100 },
                  order_type: "ORDER",
                  items: [
                    {
                      name: `Pembayaran ${wallet.name}`,
                      amount: { value: 0, offset: 100 },
                      quantity: 1,
                      sale_amount: { value: 0, offset: 100 }
                    }
                  ]
                },
                payment_settings: [
                  {
                    type: "payment_key",
                    payment_key: {
                      type: "IDPAYMENTACCOUNT",
                      key: wallet.key,
                      name: wallet.name,
                      institution_name: wallet.name,
                      full_name_on_account: global.ownername,
                      account_type: "ewallet"
                    }
                  }
                ],
                share_payment_status: false,
                referral: "chat_attachment"
              })
            }
          ]
        }
      }
    },
    {
      additionalNodes: [
        { tag: "biz", attrs: { native_flow_name: "payment_key_info" } }
      ],
      userJid: m.chat
    }
  )
}

handler.command = ["payment", "pay", "dana", "ovo", "gopay", "qris"]
handler.tags = ["store"]
handler.help = ["payment"]

module.exports = handler
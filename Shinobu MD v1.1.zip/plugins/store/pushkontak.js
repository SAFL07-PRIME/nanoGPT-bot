let handler = async (m, { sock, text, command }) => {
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))
  const isOwner = m.isOwner
  const botNumber = m.botNumber
  const namaContact = global.db.settings.namaSaveContact
  const jedaPush = global.db.settings.jedaPushkontak

  switch (command) {

    case "pushkontak":
    case "puskontak": {
      if (!text) return m.reply(`*example:*\n${m.cmd} teks pesannya`)

      global.textpushkontak = text

      const groups = await sock.groupFetchAllParticipating()
      if (!groups || Object.keys(groups).length === 0)
        return m.reply("❌ Bot tidak tergabung di grup manapun.")

      global.dataAllGrup = groups

      const rows = Object.values(groups).map(g => ({
        title: g.subject || "Tanpa Nama",
        description: `${g.participants.length} member`,
        id: `.pushkontak-response ${g.id}`
      }))

      await sock.sendMessage(m.chat, {
        buttons: [{
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Grup' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Grup',
              sections: [{
                rows: rows.map(v => ({
                  title: v.title,
                  description: v.description,
                  id: v.id
                }))
              }]
            })
          }
        }],
        headerType: 1,
        text: `\n📢 *PUSHKONTAK*\nSilahkan pilih grup target\n`
      }, { quoted: m })
    }
    break

    case "pushkontak-response": {
      if (!global.textpushkontak || !global.dataAllGrup)
        return m.reply("❌ Data pushkontak tidak ditemukan\nSilahkan ulangi dengan *.pushkontak pesan*")

      const groupId = text
      const groupData = global.dataAllGrup[groupId]
      if (!groupData) return m.reply("❌ Grup tidak ditemukan.")

      const messageText = global.textpushkontak
      global.statusPushkontak = true
      
      const members = groupData.participants
        .map(v => v.jid || v.phoneNumber || v.id)
        .filter(jid => jid && jid !== botNumber)

      await m.reply(
        `🚀 *Memulai Pushkontak*\n\n` +
        `📌 Grup : *${groupData.subject}*\n` +
        `👥 Total : *${members.length} member*`
      )

      let success = 0

      for (let jid of members) {
        try {
          if (!global.statusPushkontak) break

          if (/@lid/.test(jid)) jid = await sock.toPn(jid)

          let name = namaContact + " " + `#${jid.split("@")[0]}`
          await sock.saveContact(jid, name)

          await sock.sendMessage(jid, { text: messageText }, { quoted: null })

          success++
          await sleep(jedaPush)
        } catch (e) {
          console.log("Gagal kirim ke:", jid)
        }
      }

      delete global.textpushkontak
      delete global.dataAllGrup
      global.statusPushkontak = false

      return m.reply(
        `✅ *Pushkontak Selesai*\n\n` +
        `📤 Berhasil terkirim ke *${success} member*`
      )
    }
    break

    case "stoppush": {
      if (!global.statusPushkontak)
        return m.reply("Tidak ada pushkontak yang sedang berjalan!")
      global.statusPushkontak = false
      return m.reply(`Berhasil menghentikan pushkontak ✅`)
    }
    break
    
    case "setkontakpush":
    case "setnamakontak":
    case "setkontak": {
      if (!text) return m.reply(`*example:*\n${m.cmd} buyerku`)
      if (text.includes(" ")) return m.reply("Nama kontak dilarang memakai spasi!")
      global.db.settings.namaSaveContact = text
      return m.reply(`Berhasil set nama kontak pushkontak *${text}* ✅`)
    }
    break
    
    case "setjeda":
    case "setjedapush":
    case "setjedapus": {
      if (!text) return m.reply(`*example:*\n${m.cmd} 4000`)
      const jeda = Number(text)
      if (isNaN(jeda)) return m.reply(`*example:*\n${m.cmd} 4000`)
      global.db.settings.jedaPushkontak = jeda
      return m.reply(`Berhasil set jeda pushkontak *${jeda}* ms ✅`)
    }
    break    

  }
}

handler.tags = ["store"]
handler.help = ["pushkontak", "stoppush", "setkontak", "setjeda"]
handler.command = [
  "pushkontak",
  "puskontak",
  "pushkontak-response",
  "stoppush",
  "setjedapush",
  "setjeda",
  "setnamakontak",
  "setkontak"
]
handler.owner = true

module.exports = handler
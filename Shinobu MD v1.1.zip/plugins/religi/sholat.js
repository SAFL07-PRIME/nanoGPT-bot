// plugins/sholat.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { text }) => {
  if (!text) return m.reply(`*Contoh:*\n${m.cmd} Jakarta\n${m.cmd} Surabaya\n${m.cmd} Bandung`);

  await m.reply("🕌 Mencari jadwal sholat...");

  try {
    // Cari kota
    const searchRes = await axios.get(
      `https://api.aladhan.com/v1/searchByCity?city=${encodeURIComponent(text)}&country=Indonesia`
    );
    const city = searchRes.data?.data?.[0];
    if (!city) return m.reply("❌ Kota tidak ditemukan!");

    const today = new Date();
    const dd = today.getDate().toString().padStart(2, "0");
    const mm = (today.getMonth() + 1).toString().padStart(2, "0");
    const yyyy = today.getFullYear();

    const { data } = await axios.get(
      `https://api.aladhan.com/v1/timingsByCity/${dd}-${mm}-${yyyy}?city=${encodeURIComponent(text)}&country=Indonesia&method=11`
    );

    const timings = data?.data?.timings;
    if (!timings) return m.reply("❌ Gagal mendapatkan jadwal sholat.");

    const teks = `
🕌 *Jadwal Sholat*
📍 Kota: *${global.ucwords(text)}*
📅 Tanggal: *${global.tanggal(today)}*

🌅 Subuh    : ${timings.Fajr}
🌞 Dzuhur   : ${timings.Dhuhr}
🌤 Ashar    : ${timings.Asr}
🌇 Maghrib  : ${timings.Maghrib}
🌙 Isya     : ${timings.Isha}
✨ Imsak    : ${timings.Imsak}
🌄 Terbit   : ${timings.Sunrise}

_Semua waktu dalam WIB_`;

    return m.reply(teks);
  } catch (err) {
    m.reply("❌ Gagal mengambil jadwal sholat: " + err.message);
  }
};

handler.command = ["sholat", "jadwalsholat", "shalat"];
handler.tags = ["tools"];
handler.help = ["sholat <kota>"];

module.exports = handler;

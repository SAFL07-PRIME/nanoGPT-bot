// plugins/rpg-casino.js — Casino/Judi dari Ourin MD 3.1

function getRpgUser(sender) {
  if (!global.db.users[sender]) global.db.users[sender] = {};
  const u = global.db.users[sender];
  if (!u.rpg) u.rpg = { balance: 0, bank: 0, exp: 0, level: 1, potion: 0, diamond: 0, gold: 0 };
  return u.rpg;
}

let handler = async (m, { args }) => {
  const rpg = getRpgUser(m.sender);
  let bet = args?.[0];

  if (!bet) {
    return m.reply(
      `🎰 *LAS VEGAS KELILING* 🎰\n\n` +
      `Selamat datang di Kasino! Mau ngadu nasib sama bandar?\n\n` +
      `*Cara Taruhan:*\n` +
      `👉 \`${m.cmd} <jumlah>\`\n\n` +
      `Contoh:\n👉 \`${m.cmd} 10000\`\n👉 \`${m.cmd} all\` (Nekat bener!)`
    );
  }

  if (/^all$/i.test(bet)) {
    bet = rpg.balance || 0;
  } else {
    bet = parseInt(bet);
  }

  if (isNaN(bet) || bet < 1000) {
    return m.reply(`Hadeh... mau judi kok modal receh? 💸\nMinimal taruhan di sini *Rp 1.000* bro!`);
  }

  if (bet > (rpg.balance || 0)) {
    return m.reply(
      `Jangan ngutang bos! 😂\nUang lu cuma *Rp ${(rpg.balance || 0).toLocaleString("id-ID")}* tapi sok-sokan taruhan *Rp ${bet.toLocaleString("id-ID")}*.\nSana kerja dulu!`
    );
  }

  await m.react("🎰");
  await m.reply(`🎲 Bandar mengocok dadu dan memutar roda Roulette... Tahan napas lu!`);
  await new Promise((r) => setTimeout(r, 2000));

  const playerScore = Math.floor(Math.random() * 100);
  const botScore = Math.floor(Math.random() * 100);

  let result, emoji, moneyChange, taunt;

  if (playerScore > botScore) {
    const multiplier = playerScore - botScore > 50 ? 2.5 : 1.8;
    moneyChange = Math.floor(bet * multiplier);
    rpg.balance += moneyChange;
    emoji = "🎉";
    result = "MENANG!";
    taunt = "Wah gila lu beruntung banget! Bandar nangis darah! 😭💰";
  } else if (playerScore === botScore) {
    moneyChange = 0;
    emoji = "🤝";
    result = "SERI!";
    taunt = "Untung lu, taruhan balik. Bandar juga bingung. 😅";
  } else {
    moneyChange = -bet;
    rpg.balance += moneyChange;
    emoji = "💀";
    result = "KALAH!";
    taunt = "HAHAHA modyar lu! Duit ludes ke kantong bandar! 🤣";
  }

  await m.react(emoji);
  return m.reply(
    `${emoji} *${result}*\n\n` +
    `🎲 Skor Kamu: *${playerScore}*\n` +
    `🎲 Skor Bandar: *${botScore}*\n\n` +
    `💰 ${moneyChange >= 0 ? "Untung" : "Rugi"}: *Rp ${Math.abs(moneyChange).toLocaleString("id-ID")}*\n` +
    `💵 Saldo: *Rp ${rpg.balance.toLocaleString("id-ID")}*\n\n` +
    `_${taunt}_`
  );
};

handler.command = ["casino", "judi", "gamble"];
handler.tags = ["rpg"];
handler.help = ["casino <jumlah>"];
module.exports = handler;

// plugins/rpg-pet.js — Pet/Hewan Peliharaan dari Ourin MD 3.1 (versi simplified)

const PET_TYPES = {
  cat: { name: "🐱 Kucing", baseStats: { attack: 5, defense: 3, luck: 5 } },
  dog: { name: "🐕 Anjing", baseStats: { attack: 8, defense: 5, luck: 2 } },
  bird: { name: "🐦 Burung", baseStats: { attack: 4, defense: 2, luck: 8 } },
  fish: { name: "🐟 Ikan", baseStats: { attack: 2, defense: 2, luck: 10 } },
  rabbit: { name: "🐰 Kelinci", baseStats: { attack: 3, defense: 4, luck: 6 } },
};

function getRpgUser(sender) {
  if (!global.db.users[sender]) global.db.users[sender] = {};
  const u = global.db.users[sender];
  if (!u.rpg) u.rpg = { balance: 0, bank: 0, exp: 0, level: 1, potion: 0, diamond: 0, gold: 0 };
  return u.rpg;
}

let handler = async (m, { args }) => {
  const rpg = getRpgUser(m.sender);
  const action = args?.[0]?.toLowerCase();

  // ── Adopsi pet pertama ──────────────────
  if (!rpg.pet) {
    if (action === "adopt" && args[1]) {
      const type = args[1].toLowerCase();
      const petInfo = PET_TYPES[type];
      if (!petInfo) {
        let txt = `❌ Jenis pet tidak ada!\n\n*Pilihan:*\n`;
        for (const [key, p] of Object.entries(PET_TYPES)) txt += `> \`${m.cmd} adopt ${key}\` - ${p.name}\n`;
        return m.reply(txt);
      }
      rpg.pet = {
        type, name: petInfo.name.split(" ")[1],
        level: 1, exp: 0, hunger: 100,
        stats: { ...petInfo.baseStats },
      };
      return m.reply(`🎉 Selamat! Kamu mengadopsi *${petInfo.name}*!\n\nBeri nama dengan: \`${m.cmd} rename <nama>\`\nBeri makan dengan: \`${m.cmd} feed\``);
    }

    let txt = `😭 Kamu belum punya hewan peliharaan!\n\n*Cara adopsi:*\n`;
    for (const [key, p] of Object.entries(PET_TYPES)) txt += `> \`${m.cmd} adopt ${key}\` - ${p.name}\n`;
    return m.reply(txt);
  }

  const pet = rpg.pet;
  const petInfo = PET_TYPES[pet.type] || PET_TYPES.cat;

  // ── Status ───────────────────────────────
  if (!action || !["feed", "train", "status", "rename"].includes(action)) {
    const hungerStatus = pet.hunger >= 70 ? "😊 Senang & Kenyang" : pet.hunger >= 40 ? "😐 Biasa Aja" : "😰 Keroncongan Parah!";
    const expNeeded = (pet.level || 1) * 100;

    return m.reply(
      `🐾 *PROFIL PELIHARAAN*\n\n` +
      `*${pet.name}* (${petInfo.name})\n` +
      `📊 Level: *${pet.level || 1}* | EXP: *${pet.exp || 0}/${expNeeded}*\n` +
      `🍖 Perut: *${pet.hunger}/100* (${hungerStatus})\n\n` +
      `*Stats:*\n` +
      `⚔️ Attack: *${pet.stats?.attack || petInfo.baseStats.attack}*\n` +
      `🛡️ Defense: *${pet.stats?.defense || petInfo.baseStats.defense}*\n` +
      `🍀 Luck: *${pet.stats?.luck || petInfo.baseStats.luck}*\n\n` +
      `*Interaksi:*\n` +
      `> \`${m.cmd} feed\` - Kasih makan\n` +
      `> \`${m.cmd} train\` - Latih biar kuat\n` +
      `> \`${m.cmd} rename <nama>\` - Ganti nama`
    );
  }

  // ── Feed ─────────────────────────────────
  if (action === "feed") {
    if (pet.hunger >= 100) return m.reply(`Perut *${pet.name}* udah kenyang banget! 🤢`);

    const hungerGain = 30, expGain = 15;
    pet.hunger = Math.min(100, pet.hunger + hungerGain);
    pet.exp = (pet.exp || 0) + expGain;

    let levelUpMsg = "";
    const expNeeded = (pet.level || 1) * 100;
    if (pet.exp >= expNeeded) {
      pet.level = (pet.level || 1) + 1;
      pet.exp -= expNeeded;
      pet.stats = pet.stats || { ...petInfo.baseStats };
      pet.stats.attack += 2; pet.stats.defense += 1; pet.stats.luck += 1;
      levelUpMsg = `\n🎉 *${pet.name} LEVEL UP jadi Level ${pet.level}!*`;
    }

    await m.react("🍖");
    return m.reply(`Nyam nyam! 🤤\n\n*${pet.name}* makan dengan lahap!\n🍖 Perut: +${hungerGain} (${pet.hunger}/100)\n✨ EXP: +${expGain}${levelUpMsg}`);
  }

  // ── Train ────────────────────────────────
  if (action === "train") {
    if (pet.hunger < 20) return m.reply(`*${pet.name}* lagi kelaparan, kasih makan dulu! 😭`);

    pet.hunger = Math.max(0, pet.hunger - 15);
    const expGain = Math.floor(Math.random() * 20) + 10;
    pet.exp = (pet.exp || 0) + expGain;

    let levelUpMsg = "";
    const expNeeded = (pet.level || 1) * 100;
    if (pet.exp >= expNeeded) {
      pet.level = (pet.level || 1) + 1;
      pet.exp -= expNeeded;
      pet.stats = pet.stats || { ...petInfo.baseStats };
      pet.stats.attack += 2; pet.stats.defense += 1; pet.stats.luck += 1;
      levelUpMsg = `\n🎉 *${pet.name} LEVEL UP jadi Level ${pet.level}!*`;
    }

    await m.react("💪");
    return m.reply(`💪 *${pet.name}* berlatih keras!\n✨ EXP: +${expGain}\n🍖 Perut: -15${levelUpMsg}`);
  }

  // ── Rename ───────────────────────────────
  if (action === "rename") {
    const newName = args.slice(1).join(" ");
    if (!newName) return m.reply(`*Contoh:*\n> ${m.cmd} rename Si Comel`);
    pet.name = newName;
    return m.reply(`✅ Pet kamu sekarang bernama *${newName}*!`);
  }
};

handler.command = ["pet", "mypet", "hewanku", "peliharaan"];
handler.tags = ["rpg"];
handler.help = ["pet", "pet adopt <jenis>", "pet feed", "pet train"];
module.exports = handler;

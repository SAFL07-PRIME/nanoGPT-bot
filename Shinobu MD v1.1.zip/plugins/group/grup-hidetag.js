let handler = async (m, { sock, text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  if (!text) {
    return m.reply(`*example:*\n${m.cmd} hai semuanya`)
  }

  try {
    if (!m.metadata || !m.metadata.participants) {
      return m.reply("Gagal mendapatkan daftar anggota grup.")
    }

    const members = m.metadata.participants.map(v =>
      v.id?.includes("@s.whatsapp.net") ? v.id : v.jid
    )

    await sock.sendMessage(
      m.chat,
      {
        text: text,
        mentions: members
      },
      { quoted: null }
    )

  } catch (err) {
    console.error("Hidetag error:", err)
    m.reply("Terjadi kesalahan saat mengirim hidetag.")
  }
}

handler.command = ["ht", "hidetag"]
handler.tags = ["group"]
handler.help = ["hidetag <teks>"]
handler.group = true

module.exports = handler
let handler = async (m) => m

handler.before = async function (m, { sock }) {

  if (m.mtype !== "groupStatusMentionMessage") return false
  if (!global.db.groups[m.chat]?.antitagsw) return false
  if (m.isAdmin || m.isOwner) return false

  try {
    const messageId = m.key.id
    const participantToDelete = m.key.participant || m.sender

    await sock.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: messageId,
        participant: participantToDelete
      }
    })

  } catch (err) {
    console.error("AntitagSW error:", err)
  }

  return true
}

handler.group = true
handler.botAdmin = true

module.exports = handler
const handler = async (m, { sock, text, command, reply, usedPrefix, db }) => {

  const input = text?.toLowerCase();
  if (!['on', 'off'].includes(input)) {
    return reply(`Contoh: ${usedPrefix + command} on/off`);
  }

  const dbValue = input === 'on' ? 1 : 0;

  try {
    await db('groups', m.chat, 'antipromosi', dbValue);

    reply(`Fitur *antipromosi* berhasil di *${input === 'on' ? 'aktifkan' : 'matikan'}*`);
  } catch (e) {
    console.error(e);
    reply('❌ Gagal menyimpan ke database.');
  }
}

handler.command = ['antipromosi', 'noporn']
handler.tags = ["plugins"];
handler.help = 'antipromosi', 'noporn';;
handler.owner = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;

module.exports = handler;
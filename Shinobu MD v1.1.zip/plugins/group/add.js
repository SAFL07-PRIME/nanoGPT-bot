// plugins/grup/add.js
const handler = async (m, { sock, text, command, reply, usedPrefix }) => {

  let nomor = text?.replace(/[^0-9]/g, "");

  if (m.mentionedJid?.[0]) nomor = m.mentionedJid[0].split("@")[0];
  else if (m.quoted?.sender) nomor = m.quoted.sender.split("@")[0];

  if (!nomor) return reply(`Contoh: ${usedPrefix}${command} 628xxxx`);
  if (nomor.length < 8) return reply("Nomor tidak valid!");

  const target = nomor + "@s.whatsapp.net";

  try {
    await sock.groupParticipantsUpdate(m.chat, [target], "add");
    await sock.sendMessage(m.chat, {
      text: `Berhasil menambahkan @${nomor}`,
      mentions: [target]
    }, { quoted: m });
  } catch (err) {
    console.error(err);
    reply("Gagal menambahkan. Nomor mungkin privat / tidak aktif / sudah di grup.");
  }
};

handler.command = ["add"]
handler.tags = ["plugins"];
handler.help = "add";;
handler.owner = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;

module.exports = handler;
// plugins/_antitoxic.js — dari Ourin MD 3

const TOXIC_WORDS = [
  "anjing", "bangsat", "kontol", "memek", "ngentot", "pepek",
  "babi", "bajingan", "goblok", "tolol", "idiot", "brengsek",
  "tai", "kampret", "asu", "jancok", "dancok", "cok", "lonte",
  "pelacur", "sundel", "bedebah", "setan", "iblis",
];

let warnData = {}; // { chatId_userId: count }

let handler = async (m) => m;

handler.before = async function (m, { sock }) {
  if (!m.isGroup) return false;
  if (!global.db.groups[m.chat]?.antitoxic) return false;
  if (m.isAdmin || m.isOwner) return false;

  const text = (m.body || "").toLowerCase();
  const hasToxic = TOXIC_WORDS.some((w) => text.includes(w));
  if (!hasToxic) return false;

  const key = `${m.chat}_${m.sender}`;
  warnData[key] = (warnData[key] || 0) + 1;
  const warn = warnData[key];
  const max = global.db.groups[m.chat]?.antitoxicMax || 3;
  const method = global.db.groups[m.chat]?.antitoxicAction || "kick";

  try {
    // Hapus pesan toxic
    await sock.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: m.sender,
      },
    });
  } catch {}

  if (warn >= max) {
    warnData[key] = 0;
    try {
      if (method === "kick") {
        await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove");
        await sock.sendMessage(m.chat, {
          text: `🚫 @${m.sender.split("@")[0]} di-kick karena toxic. (${warn}/${max})`,
          mentions: [m.sender],
        });
      } else {
        await sock.sendMessage(m.chat, {
          text: `🚫 @${m.sender.split("@")[0]} di-${method} karena toxic. (${warn}/${max})`,
          mentions: [m.sender],
        });
      }
    } catch (e) {
      console.error("AntiToxic action error:", e);
    }
  } else {
    await sock.sendMessage(m.chat, {
      text: `⚠ @${m.sender.split("@")[0]} berkata kasar.\nPeringatan ke ${warn} dari ${max}.`,
      mentions: [m.sender],
    });
  }

  return true;
};

handler.group = true;
module.exports = handler;

let handler = async (m, { text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")
  
  const status = global.db.groups[m.chat]?.antilink ? "Aktif ✅" : "Tidak Aktif ❌"
  if (!text) {
    return m.reply(`*example:*\n${m.cmd} on/off\n\n- Group: ${m?.metadata?.subject || "Unknown"}\n- Antilink Status: ${status}`)
  }
  
  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

  if (/on/i.test(text)) {
    global.db.groups[m.chat].antilink = true
    m.reply(`✅ Antilink berhasil diaktifkan dalam grup chat ${m.metadata?.subject || "Unknown"}`)
  } else if (/off/i.test(text)) {
    global.db.groups[m.chat].antilink = false
    m.reply(`❌ Antilink berhasil dimatikan dalam grup chat ${m.metadata?.subject || "Unknown"}`)
  } else {
    m.reply("Opsi Tidak Valid!\nGunakan on / off")
  }
}

handler.command = ["antilink"]
handler.tags = ["group"]
handler.help = ["antilink on/off"]
handler.group = true

module.exports = handler
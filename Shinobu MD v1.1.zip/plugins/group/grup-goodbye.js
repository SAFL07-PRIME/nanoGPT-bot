// plugins/grup-goodbye.js — dari Ourin MD 3

let handler = async (m, { text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("🛡️ Admin only!");
  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};

  const status = global.db.groups[m.chat]?.goodbye ? "✅ Aktif" : "❌ Tidak Aktif";
  if (!text) {
    return m.reply(`*Goodbye/Leave Message*\nStatus: ${status}\n\nGunakan: ${m.cmd} on/off`);
  }

  if (/^on$/i.test(text)) {
    global.db.groups[m.chat].goodbye = true;
    m.reply("✅ Goodbye message berhasil diaktifkan!");
  } else if (/^off$/i.test(text)) {
    global.db.groups[m.chat].goodbye = false;
    m.reply("❌ Goodbye message berhasil dimatikan!");
  } else {
    m.reply("Opsi tidak valid! Gunakan: on / off");
  }
};

handler.command = ["goodbye", "bye"];
handler.tags = ["group"];
handler.help = ["goodbye on/off"];
handler.group = true;

module.exports = handler;

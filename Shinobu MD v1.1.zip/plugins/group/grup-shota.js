// plugins/grup-shota.js — Group Features dari Shota Bot MD
// mute member, afk, semat (pin)

if (!global.afkList) global.afkList = {};
if (!global.mutedMembers) global.mutedMembers = {};

let handler = async (m, { sock, command, text, args }) => {

  // ── AFK ────────────────────────────────
  if (command === "afk") {
    const alasan = text || "Tidak ada alasan";
    global.afkList[m.sender] = {
      alasan,
      waktu: Date.now(),
      chat: m.chat,
    };
    return sock.sendMessage(m.chat, {
      text: `💤 @${m.sender.split("@")[0]} sedang AFK\n\n📝 Alasan: _${alasan}_`,
      mentions: [m.sender],
    }, { quoted: m.verifiedQuoted });
  }

  // ── Mute Member ────────────────────────
  if (command === "mute") {
    if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
    if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");

    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return m.reply(`*Contoh:*\n> ${m.cmd} @tag`);
    if (target === m.sender) return m.reply("❌ Tidak bisa mute diri sendiri!");

    const durasi = parseInt(args[1]) || 5; // menit
    if (!global.mutedMembers[m.chat]) global.mutedMembers[m.chat] = {};
    global.mutedMembers[m.chat][target] = {
      until: Date.now() + durasi * 60000,
      by: m.sender,
    };

    await sock.sendMessage(m.chat, {
      text: `🔇 @${target.split("@")[0]} di-mute selama *${durasi} menit*\nOleh: @${m.sender.split("@")[0]}`,
      mentions: [target, m.sender],
    }, { quoted: m.verifiedQuoted });

    // Auto unmute
    setTimeout(async () => {
      if (global.mutedMembers[m.chat]?.[target]) {
        delete global.mutedMembers[m.chat][target];
        await sock.sendMessage(m.chat, {
          text: `🔊 @${target.split("@")[0]} sudah di-unmute!`,
          mentions: [target],
        }).catch(() => {});
      }
    }, durasi * 60000);
  }

  // ── Unmute ─────────────────────────────
  if (command === "unmute") {
    if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return m.reply(`*Contoh:*\n> ${m.cmd} @tag`);

    if (global.mutedMembers[m.chat]?.[target]) {
      delete global.mutedMembers[m.chat][target];
      return sock.sendMessage(m.chat, {
        text: `🔊 @${target.split("@")[0]} berhasil di-unmute!`,
        mentions: [target],
      }, { quoted: m.verifiedQuoted });
    }
    return m.reply("❌ Member tersebut tidak dalam keadaan mute!");
  }

  // ── Semat/Pin ──────────────────────────
  if (command === "semat" || command === "pin") {
    if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
    if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");
    if (!m.quoted) return m.reply("Reply pesan yang ingin di-pin!");

    try {
      await sock.sendMessage(m.chat, {
        pin: {
          type: 1,
          time: 86400,
          key: m.quoted.key || m.quoted.fakeObj?.key,
        },
      });
      return m.reply("📌 Pesan berhasil di-pin selama 24 jam!");
    } catch (e) {
      return m.reply("❌ Gagal pin pesan: " + e.message);
    }
  }

  // ── Unpin ──────────────────────────────
  if (command === "unpin" || command === "unsemat") {
    if (!m.isAdmin && !m.isOwner) return m.reply("🛡️ Admin only!");
    if (!m.isBotAdmin) return m.reply("🤖 Bot harus jadi admin!");
    if (!m.quoted) return m.reply("Reply pesan yang ingin di-unpin!");

    try {
      await sock.sendMessage(m.chat, {
        pin: {
          type: 2,
          time: 0,
          key: m.quoted.key || m.quoted.fakeObj?.key,
        },
      });
      return m.reply("📌 Pesan berhasil di-unpin!");
    } catch (e) {
      return m.reply("❌ Gagal unpin: " + e.message);
    }
  }

  // ── Intro ──────────────────────────────
  if (command === "intro") {
    const target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
    const user = global.db?.users?.[target] || {};
    const rpg = user?.rpg || {};

    let pp = global.thumbnail;
    try { pp = await sock.profilePictureUrl(target, "image"); } catch {}

    const teks =
      `👤 *PERKENALAN*\n\n` +
      `📛 Nama: *${m.pushName || "Unknown"}*\n` +
      `📱 Nomor: *+${target.split("@")[0]}*\n` +
      `💎 Status: *${m.isPremium ? "Premium" : "Regular"}*\n` +
      `⚔️ Level RPG: *${rpg.level || 1}*\n` +
      `💰 Balance: *${(rpg.balance || 0).toLocaleString("id-ID")}*\n` +
      `⚡ Energi: *${user.energi || global.energiDefault || 50}*\n\n` +
      `_Halo! Senang berkenalan denganmu_ 😊`;

    await sock.sendMessage(m.chat, {
      image: { url: pp },
      caption: teks,
      mentions: [target],
    }, { quoted: m.verifiedQuoted });
  }
};

// ── Before hook — cek mute ────────────────
handler.before = async function (m, { sock }) {
  if (!m.isGroup) return false;
  const muted = global.mutedMembers?.[m.chat]?.[m.sender];
  if (!muted) return false;

  if (Date.now() > muted.until) {
    delete global.mutedMembers[m.chat][m.sender];
    return false;
  }

  // Hapus pesan member yang dimute
  try {
    await sock.sendMessage(m.chat, {
      delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender },
    });
  } catch {}
  return true;
};

// ── All hook — cek AFK ────────────────────
handler.all = async function (m, { sock }) {
  if (!m.body || !global.afkList) return;

  // Kalau yang ngomong lagi AFK, remove AFK status
  if (global.afkList[m.sender]) {
    const afkData = global.afkList[m.sender];
    const durasi = Math.floor((Date.now() - afkData.waktu) / 60000);
    delete global.afkList[m.sender];

    await sock.sendMessage(m.chat, {
      text: `👋 @${m.sender.split("@")[0]} sudah tidak AFK!\nTadi AFK selama *${durasi} menit*`,
      mentions: [m.sender],
    }).catch(() => {});
  }

  // Kalau mention seseorang yang AFK
  const mentions = m.mentionedJid || [];
  for (const jid of mentions) {
    if (!global.afkList[jid]) continue;
    const afkData = global.afkList[jid];
    const durasi = Math.floor((Date.now() - afkData.waktu) / 60000);

    await sock.sendMessage(m.chat, {
      text: `💤 @${jid.split("@")[0]} sedang AFK (${durasi} menit)\n📝 Alasan: _${afkData.alasan}_`,
      mentions: [jid],
    }).catch(() => {});
  }
};

handler.command = ["afk", "mute", "unmute", "semat", "pin", "unpin", "unsemat", "intro"];
handler.tags = ["group"];
handler.help = ["afk [alasan]", "mute @tag [menit]", "unmute @tag", "semat [reply]", "intro"];
handler.group = true;
module.exports = handler;

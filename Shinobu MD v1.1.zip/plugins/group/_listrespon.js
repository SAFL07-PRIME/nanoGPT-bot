let handler = async (m) => m

handler.before = async function (m) {
  if (!m.text) return false

  global.db.settings = global.db.settings || {}
  global.db.settings.list = global.db.settings.list || {}

  const list = global.db.settings.list
  const text = m.text.trim().toLowerCase()
  if (!list[text]) return false

  try {
    await m.reply(list[text])
  } catch (err) {
    console.error("List response error:", err)
  }

  return true
}

module.exports = handler
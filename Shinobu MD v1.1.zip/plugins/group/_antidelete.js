// plugins/_antidelete.js — dari Ourin MD 3
const { downloadContentFromMessage } = require("dekzymarket-cyber");

let handler = async (m) => m;

handler.before = async function (m, { sock }) {
  if (!m.isGroup) return false;
  if (m.mtype !== "protocolMessage") return false;
  if (!global.db.groups[m.chat]?.antidelete) return false;

  try {
    const deletedKey = m.message?.protocolMessage?.key;
    if (!deletedKey) return false;

    const user = deletedKey.participant || m.sender;
    const userTag = `@${user.split("@")[0]}`;

    await sock.sendMessage(
      m.chat,
      {
        text: `🗑️ *AntiDelete* — ${userTag} menghapus pesan.`,
        mentions: [user],
      },
      { quoted: null }
    );
  } catch (e) {
    console.error("AntiDelete error:", e);
  }

  return false;
};

handler.group = true;
module.exports = handler;

// plugins/rules.js — dari Ourin MD 3

let handler = async (m, { sock, text, command }) => {
  const group = global.db.groups?.[m.chat] || {};

  if (command === "setrules") {
    if (!m.isOwner && !m.isAdmin) return m.reply("🛡️ Admin only!");
    if (!text) return m.reply(`*Contoh:*\n${m.cmd} 1. Dilarang spam\n2. Hormati sesama`);
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    global.db.groups[m.chat].rules = text;
    return m.reply("✅ Rules grup berhasil disimpan!");
  }

  if (command === "delrules") {
    if (!m.isOwner && !m.isAdmin) return m.reply("🛡️ Admin only!");
    if (!global.db.groups[m.chat]) return m.reply("Belum ada rules.");
    global.db.groups[m.chat].rules = null;
    return m.reply("✅ Rules grup berhasil dihapus!");
  }

  // View rules
  if (!group.rules) {
    return m.reply("❌ Belum ada rules yang ditetapkan untuk grup ini.\n\nAdmin bisa set rules dengan: *.setrules <isi rules>*");
  }

  const meta = await sock.groupMetadata(m.chat).catch(() => ({}));
  const teks = `
📋 *Rules ${meta?.subject || "Grup"}*

${group.rules}`;

  await sock.sendMessage(m.chat, { text: teks }, { quoted: m });
};

handler.command = ["rules", "setrules", "delrules"];
handler.tags = ["group"];
handler.help = ["rules", "setrules <teks>", "delrules"];
handler.group = true;

module.exports = handler;

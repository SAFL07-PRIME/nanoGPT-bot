// plugins/grup-protection.js
// Toggle: antiviewonce, antidelete, antitoxic, antidocument, antisticker, antimedia, antibot

let handler = async (m, { text, command }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("🛡️ Khusus admin atau owner!");

  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
  const g = global.db.groups[m.chat];

  const featureMap = {
    antiviewonce: "antiviewonce",
    antivo: "antiviewonce",
    antidelete: "antidelete",
    antidel: "antidelete",
    antitoxic: "antitoxic",
    antidocument: "antidocument",
    antidoc: "antidocument",
    antisticker: "antisticker",
    antistiker: "antisticker",
    antimedia: "antimedia",
    antibot: "antibot",
  };

  const feature = featureMap[command];
  if (!feature) return;

  if (!text) {
    const status = g[feature] ? "✅ Aktif" : "❌ Tidak Aktif";
    return m.reply(`*${command}*\nStatus: ${status}\n\nGunakan: ${m.cmd} on/off`);
  }

  if (/^on$/i.test(text)) {
    g[feature] = true;
    m.reply(`✅ *${command}* berhasil diaktifkan di grup ini.`);
  } else if (/^off$/i.test(text)) {
    g[feature] = false;
    m.reply(`❌ *${command}* berhasil dimatikan di grup ini.`);
  } else {
    m.reply("Opsi tidak valid! Gunakan: on / off");
  }
};

handler.command = [
  "antiviewonce", "antivo",
  "antidelete", "antidel",
  "antitoxic",
  "antidocument", "antidoc",
  "antisticker", "antistiker",
  "antimedia",
  "antibot",
];
handler.tags = ["group"];
handler.help = [
  "antiviewonce on/off",
  "antidelete on/off",
  "antitoxic on/off",
  "antidocument on/off",
  "antisticker on/off",
  "antimedia on/off",
  "antibot on/off",
];
handler.group = true;

module.exports = handler;

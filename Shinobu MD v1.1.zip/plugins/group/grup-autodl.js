let handler = async (m, { text }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("Khusus admin!")

  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

  const status = global.db.groups[m.chat]?.autodl ? "Aktif ✅" : "Tidak Aktif ❌"

  if (!text) {
    return m.reply(`*example:*\n${m.cmd} on/off

*list auto downloader support:*
- Tiktok
- Instagram
- Github
- Npmjs`)
  }

  if (/on/i.test(text)) {
    global.db.groups[m.chat].autodl = true
    m.reply(`✅ Auto Downloader berhasil diaktifkan di grup ${m.metadata?.subject || "Unknown"}`)
  } else if (/off/i.test(text)) {
    global.db.groups[m.chat].autodl = false
    m.reply(`❌ Auto Downloader berhasil dimatikan di grup ${m.metadata?.subject || "Unknown"}`)
  } else {
    m.reply("Opsi Tidak Valid!\nGunakan on / off")
  }
}

handler.command = ["autodl", "autodownload"]
handler.tags = ["group"]
handler.help = ["autodl on/off"]
handler.group = true

module.exports = handler
// plugins/fun-terimatembak.js — handler terima/tolak tembakan

let handler = async (m, { sock, command }) => {
  const db = global.db?.users || {};
  const sessions = Object.entries(global.tembakSessions || {})
    .filter(([k, v]) => v.target === m.sender && v.chat === m.chat);

  const valid = sessions.find(([k, v]) => Date.now() - v.timestamp < 3600000);
  if (!valid) return m.reply("❌ Tidak ada yang nembak kamu saat ini!");

  const [sessKey, sessData] = valid;
  if (!db[m.sender]) db[m.sender] = {};
  if (!db[m.sender].fun) db[m.sender].fun = {};
  if (!db[sessData.shooter]) db[sessData.shooter] = {};
  if (!db[sessData.shooter].fun) db[sessData.shooter].fun = {};

  delete global.tembakSessions[sessKey];

  if (command === "terima") {
    db[m.sender].fun.pasangan = sessData.shooter;
    db[sessData.shooter].fun.pasangan = m.sender;
    await m.react("💕");
    return sock.sendMessage(m.chat, {
      text: `💕 *WIDIHHHH CIE CIE DITERIMA!*\n\n@${m.sender.split("@")[0]} dan @${sessData.shooter.split("@")[0]} resmi *PACARAN!* 💍\n\nSemoga langgeng dan bahagia ya! 🎉`,
      mentions: [m.sender, sessData.shooter],
    }, { quoted: m });
  } else {
    delete db[sessData.shooter]?.fun?.tembakTarget;
    await m.react("💔");
    return sock.sendMessage(m.chat, {
      text: `💔 *WADUHH, YANG SABAR YAK* @${sessData.shooter.split("@")[0]}\n\n@${m.sender.split("@")[0]} menolak tembakan kamu\n\nSabar ya, masih banyak ikan di laut! 😢`,
      mentions: [m.sender, sessData.shooter],
    }, { quoted: m });
  }
};

handler.command = ["terima", "tolak"];
handler.tags = ["fun"];
handler.help = ["terima", "tolak"];
module.exports = handler;

// plugins/fun-bucin.js — dari Ourin MD 3

const BUCIN = [
  "Kamu tau kenapa aku suka hujan? Karena hujan itu seperti kamu, sejuk di hati 🌧️",
  "Aku bukan pilot, tapi aku bisa buat hatimu terbang tinggi bersamaku 💕",
  "Kamu adalah alasan kenapa aku senyum tanpa sebab 😊",
  "Kalau kamu bintang, aku mau jadi langit yang selalu nemenin kamu ✨",
  "Aku gak butuh GPS, karena hatiku udah nunjuk ke arahmu 💘",
  "Kamu tau bedanya kamu sama kopi? Kopi bikin melek, kamu bikin aku nggak bisa tidur mikirin kamu ☕",
  "Boleh pinjam hatimu? Janji bakal dijaga selamanya 💖",
  "Kalau cinta itu adalah lagu, kamu adalah melodi terindahnya 🎵",
  "Aku butuh 3 hal: Matahari, Bulan, dan Kamu 🌙",
  "Kamu adalah puzzle terakhir yang kubutuhkan untuk melengkapi hidupku 🧩",
  "Senyummu itu bisa bikin badai berhenti sejenak ☀️",
  "Aku tidak percaya cinta pandangan pertama, sampai aku melihatmu 👀💕",
  "Kamu itu kayak wifi, selalu aku cari sinyalmu 📶❤️",
  "Kalau hatiku adalah rumah, kamu adalah penghuninya 🏠💕",
  "Dunia ini indah, tapi jauh lebih indah dengan kamu di dalamnya 🌍✨",
  "Aku mau jadi pelangi di hari hujanmu 🌈",
  "Nama kamu sudah tersimpan di hatiku sejak lama 💝",
  "Aku nggak butuh bintang untuk membuat malam ini indah, cukup kamu ⭐",
  "Setiap hari bersamamu terasa seperti liburan 🌴💕",
  "Kamu adalah password Wi-Fi hatiku, semua orang mau tahu 😂💕",
];

let handler = async (m) => {
  const q = BUCIN[Math.floor(Math.random() * BUCIN.length)];
  return m.reply(`💌 *ɢᴏᴍʙᴀʟ*\n\n\`\`\`"${q}"\`\`\``);
};

handler.command = ["bucin", "gombal", "love", "romantis"];
handler.tags = ["fun"];
handler.help = ["bucin"];
module.exports = handler;

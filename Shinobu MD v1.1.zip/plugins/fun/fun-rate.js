// plugins/fun-rate.js — dari Ourin MD 3

const ratings = [
  { score: "10/10", comment: "Sempurna! Nggak ada duanya! 🔥" },
  { score: "9/10", comment: "Hampir sempurna! Keren banget! 😎" },
  { score: "8/10", comment: "Bagus banget! Mantap! 👍" },
  { score: "7/10", comment: "Cukup bagus, di atas rata-rata!" },
  { score: "6/10", comment: "Lumayan, bisa lebih baik lagi." },
  { score: "5/10", comment: "Biasa aja sih, standar. 😐" },
  { score: "4/10", comment: "Hmm, kurang sedikit. 🤔" },
  { score: "3/10", comment: "Perlu banyak perbaikan. 😅" },
  { score: "2/10", comment: "Aduh, masih jauh dari bagus. 😬" },
  { score: "1/10", comment: "Maaf, tapi ini parah. 💀" },
  { score: "100/10", comment: "LEGEND! Beyond perfect! 🏆" },
  { score: "11/10", comment: "Melebihi ekspektasi! ✨" },
  { score: "69/100", comment: "Nice... 😏" },
  { score: "∞/10", comment: "Gacor kang 💪" },
  { score: "7.5/10", comment: "Solid! Good job! 🎯" },
  { score: "9.5/10", comment: "Near perfection! 🌟" },
  { score: "-1/10", comment: "Aku nggak tau harus ngomong apa... 😶" },
  { score: "???/10", comment: "Error 404: Rating not found. 🤖" },
];

let handler = async (m) => {
  if (!m.text) return m.reply(`⭐ *ʀᴀᴛᴇ*\n\n> Masukkan sesuatu untuk dinilai!\n\n*Contoh:*\n> ${m.cmd} wajahku`);
  const r = ratings[Math.floor(Math.random() * ratings.length)];
  return m.reply(`⭐ *Rate: ${m.text}*\n\n> Rating: *${r.score}*\n> ${r.comment}`);
};

handler.command = ["rate", "nilai", "rating"];
handler.tags = ["fun"];
handler.help = ["rate <sesuatu>"];
module.exports = handler;

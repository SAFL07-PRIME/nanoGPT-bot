// plugins/fun-cekkhodam.js — dari Shota Bot MD
const khodamList = [
  { nama: 'Kucing Rawa', deskripsi: 'Berkeliaran di rawa, suka ngeong bareng genderuwo' },
  { nama: 'Biawak Samudra', deskripsi: 'Punya insang, tapi alergi air' },
  { nama: 'Kipas Angin Tua', deskripsi: 'Suka muter tapi diem di tempat' },
  { nama: 'Farhan Kebab', deskripsi: 'Kalau dipanggil langsung bikin lapar' },
  { nama: 'Rossi Becak', deskripsi: 'Juara MotoGP tapi naik becak' },
  { nama: 'Karyawan Indomaret', deskripsi: 'Senyumnya ga pernah habis, kayak promo diskon' },
  { nama: 'Pocong Berkepala 3', deskripsi: 'Kepalanya banyak, tapi isi tetep kosong' },
  { nama: 'Kuntilanak Lucu', deskripsi: 'Suka ngelawak, bikin tuyul ketawa' },
  { nama: 'Naga Kabupaten', deskripsi: 'Naga lokal yang sering telat bayar pajak' },
  { nama: 'Tuyul Freelance', deskripsi: 'Nyuri uang tapi bayar pajak penghasilan' },
  { nama: 'Jin Perpustakaan', deskripsi: 'Suka baca buku tapi ga pernah selesai' },
  { nama: 'Wewe Gombel Viral', deskripsi: 'Udah punya TikTok dengan jutaan followers' },
  { nama: 'Leak Bali Selatan', deskripsi: 'Hobinya terbang malam tapi takut ketinggian' },
  { nama: 'Gajah Mada Reinkarnasi', deskripsi: 'Nusantara memang di hatinya, tapi KTP masih pending' },
  { nama: 'Dedemit Kondangan', deskripsi: 'Suka dateng undangan tapi ga pernah bawa amplop' },
  { nama: 'Hantu Warnet', deskripsi: 'Gentayangan di warnet tengah malam main Mobile Legends' },
  { nama: 'Siluman Warteg', deskripsi: 'Jagain nasi uduk dari jam 5 pagi' },
  { nama: 'Khodam Baper', deskripsi: 'Setiap kamu galau dia ikut nangis' },
  { nama: 'Setan Deadline', deskripsi: 'Selalu muncul pas kamu mau begadang ngerjain tugas' },
  { nama: 'Drakula Madura', deskripsi: 'Suka isap darah tapi lebih suka isap sate' },
  { nama: 'Zombie Ojol', deskripsi: 'Tetap antar pesanan walau sudah setengah mati' },
  { nama: 'Peri Jalanan', deskripsi: 'Bantu kamu nyebrang tapi minta ongkos' },
  { nama: 'Iblis Mantan', deskripsi: 'Muncul di memori tepat saat kamu udah move on' },
  { nama: 'Hantu Wifi Lemot', deskripsi: 'Selalu ada saat koneksi kamu nge-lag' },
  { nama: 'Arwah Baterai Low', deskripsi: 'Gentayangan tepat saat HP kamu 1 persen' },
];

const medals = ['🥇', '🥈', '🥉', '🏅'];
const levels = [
  { label: '⚡ LEGENDARIS', min: 90 },
  { label: '🔥 LANGKA', min: 70 },
  { label: '✨ EPIK', min: 50 },
  { label: '💫 BIASA', min: 30 },
  { label: '🌀 LEMAH', min: 0 },
];

let handler = async (m, { sock }) => {
  const text = (m.text || '').trim();
  if (!text) return m.reply(`❌ Masukkan namamu!\n\n*Contoh:*\n> ${m.cmd} Budi Santoso`);

  const data = khodamList[Math.floor(Math.random() * khodamList.length)];
  const power = Math.floor(Math.random() * 100) + 1;
  const level = levels.find(l => power >= l.min) || levels[levels.length - 1];
  const bar = '█'.repeat(Math.floor(power / 10)) + '░'.repeat(10 - Math.floor(power / 10));

  const result =
`🔮 *CEK KHODAM*

╭┈┈⬡「 👤 *IDENTITAS* 」
┃ ◈ Nama: *${text}*
╰┈┈⬡

╭┈┈⬡「 👻 *HASIL* 」
┃ ◈ Khodam: *${data.nama}*
┃ ◈ Level: *${level.label}*
┃ ◈ Kekuatan: ${bar} *${power}%*
┃ ◈ Info: _${data.deskripsi}_
╰┈┈⬡

> _Hasil ini murni random ya, jangan dibawa serius_ 😄`;

  await sock.sendMessage(m.chat, { text: result, mentions: [m.sender] }, { quoted: m.verifiedQuoted });
};

handler.command = ['cekkhodam', 'cekkodam', 'khodam', 'kodam'];
handler.tags = ['fun'];
handler.help = ['cekkhodam <nama>'];
module.exports = handler;

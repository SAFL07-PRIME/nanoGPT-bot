// plugins/fun-fml.js — FML (F*ck My Life) Story dari Ourin MD 3.1
const axios = require("axios");

const FML_LOCAL = [
  "Hari ini aku salah ketik chat ke gebetan, niatnya 'aku kangen kamu' malah jadi 'aku kandang kambing'. FML.",
  "Lagi presentasi penting, eh kamera laptop nyala sendiri nunjukin muka bangun tidur ke seluruh peserta meeting. FML.",
  "Udah nabung 6 bulan buat beli HP baru, eh HP lama ketinggalan di angkot dan gak balik lagi. FML.",
  "Niat nembak gebetan pakai bunga, eh ternyata dia alergi serbuk sari dan langsung bersin-bersin di depan aku. FML.",
  "Chat ke bos 'oke siap dikerjakan', eh ternyata salah kirim ke grup keluarga yang isinya lagi bahas warisan. FML.",
  "Udah dandan rapi buat interview kerja, eh ternyata interviewnya online dan aku salah klik jadi nyalain kamera pas masih di kamar mandi. FML.",
  "Niat romantis nyalain lilin buat candle light dinner, eh malah kebakar tisu di meja dan alarm kebakaran bunyi se-apartemen. FML.",
  "Udah PDKT 3 bulan, pas nembak ternyata dia udah punya pacar dari awal kenal. Dan pacarnya temen aku sendiri. FML.",
  "Lagi sibuk kerja remote dari kafe, eh laptop kena tumpahan kopi orang sebelah dan semua data project ilang. FML.",
  "Niat kasih kado ultah pacar diam-diam taruh di depan pintu, eh malah diambil tukang sampah karena dikira sampah. FML.",
  "Chat mantan buat say hi doang, eh malah ke-forward ke pacar baru dan jadi salah paham gede-gedean. FML.",
  "Udah belajar mati-matian buat ujian, eh pas hari H bangun kesiangan dan ujiannya udah selesai 30 menit yang lalu. FML.",
  "Niat keliatan keren naik motor di depan gebetan, eh malah nyungsep ke selokan pas belok. FML.",
  "Lagi video call sama HRD buat interview kerja, eh anak kucing tiba-tiba muncul di belakang dan ngeong kenceng banget pas momen serius. FML.",
  "Udah siapin nama anak buat masa depan sama gebetan, eh ternyata dia mau jadi 'teman aja'. FML.",
];

let handler = async (m) => {
  await m.react("🕕");

  try {
    // Coba API luar dulu
    const { data } = await axios.get("https://api.popcat.xyz/fml", { timeout: 8000 });
    if (data?.fml) {
      await m.react("✅");
      return m.reply(`😩 *FML STORY*\n\n_${data.fml}_`);
    }
    throw new Error("no data");
  } catch {
    // Fallback ke data lokal
    const story = FML_LOCAL[Math.floor(Math.random() * FML_LOCAL.length)];
    await m.react("✅");
    return m.reply(`😩 *FML STORY*\n\n_${story}_`);
  }
};

handler.command = ["fuckmylife", "fml"];
handler.tags = ["fun"];
handler.help = ["fuckmylife"];
module.exports = handler;

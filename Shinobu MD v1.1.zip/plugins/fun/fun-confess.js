// plugins/fun-confess.js — Menfess Anonim dari Ourin MD 3

if (!global.confessData) global.confessData = new Map();

let handler = async (m, { sock }) => {
  const input = (m.text || "").trim();

  if (!input || !input.includes("|")) {
    return m.reply(
      `💌 *LAYANAN MENFESS ANONIM* 💌\n\n` +
      `Mau kirim pesan rahasia ke seseorang tanpa ketahuan?\n\n` +
      `*Cara Pakai:*\n` +
      `> \`${m.cmd} nomor|pesan\`\n\n` +
      `*Contoh:*\n` +
      `> \`${m.cmd} 6281234567890|Hai, aku suka kamu!\`\n\n` +
      `> 🤫 _Identitas kamu 100% dirahasiakan!_`
    );
  }

  const [rawNumber, ...msgParts] = input.split("|");
  const message = msgParts.join("|").trim();
  let targetNum = rawNumber.trim().replace(/[^0-9]/g, "");
  if (targetNum.startsWith("0")) targetNum = "62" + targetNum.slice(1);

  if (!targetNum || targetNum.length < 10 || targetNum.length > 15)
    return m.reply("❌ Nomor tidak valid! Contoh: 6281234567890");
  if (!message || message.length < 5)
    return m.reply("❌ Pesan terlalu pendek! Minimal 5 karakter.");
  if (message.length > 1000)
    return m.reply("❌ Pesan terlalu panjang! Maksimal 1000 karakter.");

  const targetJid = targetNum + "@s.whatsapp.net";
  if (targetJid === m.sender) return m.reply("❌ Nggak bisa menfess ke diri sendiri!");

  try {
    const [onWa] = await sock.onWhatsApp(targetNum).catch(() => [{}]);
    if (!onWa?.exists) return m.reply(`❌ Nomor \`${targetNum}\` tidak terdaftar di WhatsApp!`);
  } catch {}

  try {
    const sentMsg = await sock.sendMessage(targetJid, {
      text:
        `💌 *ADA PESAN RAHASIA BUAT KAMU!* 💌\n\n` +
        `Seseorang mengirim pesan secara anonim:\n\n` +
        `💬 *Isi Pesan:*\n\`\`\`${message}\`\`\`\n\n` +
        `> 🔒 _Pesan ini dikirim anonim_\n` +
        `> ✉️ _Kamu bisa REPLY pesan ini untuk membalas!_`,
    });

    // Simpan mapping untuk reply
    global.confessData.set(sentMsg.key.id, {
      senderJid: m.sender,
      senderChat: m.chat,
      targetJid,
      createdAt: Date.now(),
    });
    // Auto delete setelah 24 jam
    setTimeout(() => global.confessData.delete(sentMsg.key.id), 24 * 60 * 60 * 1000);

    await m.reply(
      `✅ *MENFESS TERKIRIM!*\n\n` +
      `> 📱 Ke: \`${targetNum}\`\n` +
      `> 🔒 Identitas kamu aman!\n\n` +
      `_Kalau dia balas, pesannya akan diterusin ke sini_ 😉`
    );
  } catch (err) {
    m.reply("❌ Gagal mengirim menfess: " + err.message);
  }
};

// Before hook untuk handle reply menfess
handler.before = async function (m, { sock }) {
  if (!m.quoted) return false;
  const quotedId = m.quoted?.id || m.quoted?.key?.id;
  if (!quotedId) return false;
  const info = global.confessData.get(quotedId);
  if (!info) return false;
  if (m.sender !== info.targetJid) return false;

  const reply = (m.body || "").trim();
  if (!reply) return false;

  try {
    await sock.sendMessage(info.senderChat, {
      text:
        `💌 *BALASAN MENFESS KAMU!*\n\n` +
        `Orang yang kamu kirimin menfess tadi balas:\n\n` +
        `💬 *Balasan:*\n\`\`\`${reply}\`\`\`\n\n` +
        `> 🔒 _Identitas kamu tetap aman!_`,
    });
    await sock.sendMessage(m.chat, { text: "✅ Balasan kamu sudah diteruskan!" });
    global.confessData.delete(quotedId);
    return true;
  } catch { return false; }
};

handler.command = ["confess", "menfess", "anonim", "kirimpesan"];
handler.tags = ["fun"];
handler.help = ["confess nomor|pesan"];
module.exports = handler;

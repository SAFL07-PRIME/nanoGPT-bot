let handler = async (m, { sock, text }) => {
  if (!text) {
    return m.reply(`*example:*\n${m.cmd} https://github.com/Skyzopedia/Wabot`)
  }

  let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
  if (!regex.test(text)) {
    return m.reply(`*example:*\n${m.cmd} https://github.com/Skyzopedia/Wabot`)
  }

  await m.reply("Fetching github Repositori...")

  try {
    let api = `https://api.serverweb.qzz.io/download/github?apikey=skyy&url=${encodeURIComponent(text)}`
    let res = await fetch(api)
    let json = await res.json()

    if (!json.status) throw "API Error"

    let { download, filename, mimetype } = json.result

    await sock.sendMessage(
      m.chat,
      {
        document: { url: download },
        mimetype: mimetype || "application/zip",
        fileName: filename || "github.zip",
        caption: "Github Downloader ✅"
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply("Error! Repositori tidak ditemukan atau link tidak valid.")
  }
}

handler.command = ["gitclone", "git"]
handler.tags = ["download"]
handler.help = ["gitclone <url github>"]

module.exports = handler
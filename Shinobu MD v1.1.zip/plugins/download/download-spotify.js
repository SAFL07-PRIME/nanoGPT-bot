// plugins/download-spotify.js — dari Ourin MD 3
const axios = require("axios");

async function spotifyDl(url) {
  const { data } = await axios.get(
    `https://api.nexray.eu.cc/download/spotify?url=${encodeURIComponent(url)}`,
    { timeout: 30000 }
  );
  return data;
}

async function spotifySearch(query) {
  const { data } = await axios.get(
    `https://api.nexray.eu.cc/search/spotify?q=${encodeURIComponent(query)}`,
    { timeout: 15000 }
  );
  return data;
}

let handler = async (m, { sock, command }) => {
  const text = (m.text || "").trim();
  if (!text) return m.reply(
    `🎵 *sᴘᴏᴛɪꜰʏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ*\n\n` +
    `> ${m.cmd} <link/judul lagu>\n\n` +
    `*Contoh:*\n` +
    `> ${m.cmd} https://open.spotify.com/track/xxx\n` +
    `> ${m.cmd} Harleys In Hawaii`
  );

  await m.react("🎵");

  try {
    let dlUrl, title, artist, thumbnail, duration;

    if (text.includes("spotify.com")) {
      const data = await spotifyDl(text);
      const r = data?.result || data;
      dlUrl = r?.url || r?.audio_url;
      title = r?.title || r?.name || "Spotify Track";
      artist = r?.artist || r?.artists || "";
      thumbnail = r?.thumbnail || r?.image;
      duration = r?.duration || "";
    } else {
      // Search mode
      const data = await spotifySearch(text);
      const results = data?.result || data?.tracks || data?.items || [];
      if (!results.length) return m.reply("❌ Lagu tidak ditemukan!");
      const track = results[0];
      const trackUrl = track?.url || track?.external_urls?.spotify;
      if (!trackUrl) return m.reply("❌ Gagal mendapatkan link lagu.");

      const dlData = await spotifyDl(trackUrl);
      const r = dlData?.result || dlData;
      dlUrl = r?.url || r?.audio_url;
      title = track?.name || r?.title || text;
      artist = track?.artists?.[0]?.name || r?.artist || "";
      thumbnail = track?.album?.images?.[0]?.url || r?.thumbnail;
      duration = track?.duration_ms ? `${Math.floor(track.duration_ms / 60000)}:${String(Math.floor((track.duration_ms % 60000) / 1000)).padStart(2, "0")}` : "";
    }

    if (!dlUrl) throw new Error("URL download tidak ditemukan");

    const caption = `🎵 *${title}*\n🎤 ${artist}\n⏱ ${duration}`;

    if (thumbnail) {
      await sock.sendMessage(m.chat, {
        audio: { url: dlUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title,
            body: artist,
            thumbnailUrl: thumbnail,
            mediaType: 1,
            renderLargerThumbnail: false,
          },
        },
      }, { quoted: m });
    } else {
      await sock.sendMessage(m.chat, {
        audio: { url: dlUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
      }, { quoted: m });
    }

    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal download Spotify: " + err.message);
  }
};

handler.command = ["spotify", "spotifydl", "sptdl"];
handler.tags = ["Download"];
handler.help = ["spotify <link/judul>"];
module.exports = handler;

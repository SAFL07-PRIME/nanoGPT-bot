// plugins/facebook.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock, text }) => {
  if (!text || !/(facebook\.com|fb\.watch)/.test(text)) {
    return m.reply(`*Contoh:*\n${m.cmd} https://www.facebook.com/watch?v=xxx`);
  }

  await m.reply("📥 Mendownload dari Facebook...");

  try {
    const { data } = await axios.get(
      `https://api.serverweb.qzz.io/download/facebook?apikey=skyy&url=${encodeURIComponent(text)}`
    );

    if (!data?.status || !data?.result) throw new Error("Gagal mengambil data.");

    const dl = data.result;
    const dlUrl = dl.url || dl.hd || dl.sd;
    const title = dl.title || "Facebook Video";

    await sock.sendMessage(
      m.chat,
      {
        video: { url: dlUrl },
        caption: `📥 *Facebook Downloader*\n\n📌 ${title}`,
      },
      { quoted: m }
    );
  } catch (err) {
    m.reply("❌ Gagal download Facebook: " + err.message);
  }
};

handler.command = ["fb", "fbdl", "facebook", "fbvid"];
handler.tags = ["Download"];
handler.help = ["fbdl <url>"];

module.exports = handler;

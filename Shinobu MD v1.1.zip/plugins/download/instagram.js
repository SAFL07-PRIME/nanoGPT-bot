// plugins/instagram.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock, text }) => {
  if (!text || !/instagram\.com/.test(text)) {
    return m.reply(`*Contoh:*\n${m.cmd} https://www.instagram.com/reel/xxx`);
  }

  await m.reply("📥 Mendownload dari Instagram...");

  try {
    const { data } = await axios.get(
      `https://api.serverweb.qzz.io/download/instagram?apikey=skyy&url=${encodeURIComponent(text)}`
    );

    if (!data?.status) throw new Error("Gagal mengambil data Instagram");

    for (const item of data.result) {
      if (item.type === "video" || item.url_download?.includes(".mp4")) {
        await sock.sendMessage(
          m.chat,
          { video: { url: item.url_download }, caption: "Instagram Downloader ✅" },
          { quoted: m }
        );
      } else {
        await sock.sendMessage(
          m.chat,
          { image: { url: item.url_download }, caption: "Instagram Downloader ✅" },
          { quoted: m }
        );
      }
    }
  } catch (err) {
    m.reply("❌ Gagal download Instagram: " + err.message);
  }
};

handler.command = ["ig", "igdl", "instagram", "reels"];
handler.tags = ["Download"];
handler.help = ["igdl <url>"];

module.exports = handler;

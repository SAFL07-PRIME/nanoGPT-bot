// plugins/search-google.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  const query = (m.text || "").trim();
  if (!query) return m.reply(
    `🔍 *ɢᴏᴏɢʟᴇ sᴇᴀʀᴄʜ*\n\n> ${m.cmd} <kata kunci>\n\n*Contoh:*\n> ${m.cmd} cara membuat nasi goreng`
  );

  await m.react("🔍");

  try {
    const { data } = await axios.get(
      `https://api.nexray.eu.cc/search/google?q=${encodeURIComponent(query)}&limit=5`,
      { timeout: 15000 }
    );

    const results = data?.result || data?.results || data?.items || [];
    if (!results.length) return m.reply("❌ Tidak ada hasil ditemukan untuk: " + query);

    let teks = `🔍 *Google Search*\n🔎 Query: *${query}*\n\n`;
    results.slice(0, 5).forEach((r, i) => {
      const title = r.title || r.name || "No title";
      const desc = r.description || r.snippet || r.body || "";
      const url = r.url || r.link || "";
      teks += `*${i + 1}. ${title}*\n`;
      if (desc) teks += `> ${desc.slice(0, 120)}${desc.length > 120 ? "..." : ""}\n`;
      if (url) teks += `🔗 ${url}\n`;
      teks += "\n";
    });

    await m.react("✅");
    return m.reply(teks.trim());
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal searching: " + err.message);
  }
};

handler.command = ["google", "cari", "search", "googling"];
handler.tags = ["search"];
handler.help = ["google <query>"];
module.exports = handler;

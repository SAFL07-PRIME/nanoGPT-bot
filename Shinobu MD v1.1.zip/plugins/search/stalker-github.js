// plugins/stalker-github.js — dari Ourin MD 3
const axios = require("axios");

let handler = async (m, { sock }) => {
  const username = (m.text || "").trim();
  if (!username) return m.reply(
    `🐱 *ɢɪᴛʜᴜʙ sᴛᴀʟᴋᴇʀ*\n\n> ${m.cmd} <username>\n\n*Contoh:*\n> ${m.cmd} torvalds`
  );

  await m.react("🔍");

  try {
    const [userRes, repoRes] = await Promise.all([
      axios.get(`https://api.github.com/users/${username}`, { timeout: 10000 }),
      axios.get(`https://api.github.com/users/${username}/repos?sort=updated&per_page=5`, { timeout: 10000 }),
    ]);

    const u = userRes.data;
    const repos = repoRes.data;

    let teks =
      `🐱 *GitHub Stalker*\n\n` +
      `╭┈┈⬡「 👤 *PROFIL* 」\n` +
      `┃ 📛 Username: *${u.login}*\n` +
      `┃ 🔤 Nama: *${u.name || "-"}*\n` +
      `┃ 📝 Bio: ${u.bio || "-"}\n` +
      `┃ 🏢 Perusahaan: ${u.company || "-"}\n` +
      `┃ 📍 Lokasi: ${u.location || "-"}\n` +
      `┃ 🌐 Website: ${u.blog || "-"}\n` +
      `┃ 📧 Email: ${u.email || "-"}\n` +
      `╰┈┈⬡\n\n` +
      `╭┈┈⬡「 📊 *STATISTIK* 」\n` +
      `┃ 📦 Public Repos: *${u.public_repos}*\n` +
      `┃ 👥 Followers: *${u.followers}*\n` +
      `┃ 👣 Following: *${u.following}*\n` +
      `┃ ⭐ Gists: *${u.public_gists}*\n` +
      `┃ 📅 Bergabung: ${new Date(u.created_at).toLocaleDateString("id-ID")}\n` +
      `╰┈┈⬡\n`;

    if (repos.length) {
      teks += `\n╭┈┈⬡「 📂 *REPO TERBARU* 」\n`;
      repos.forEach((r) => {
        teks += `┃ ⭐${r.stargazers_count} • [${r.language || "?"}] *${r.name}*\n`;
      });
      teks += `╰┈┈⬡\n`;
    }

    teks += `\n🔗 https://github.com/${username}`;

    const ppBuf = await axios.get(u.avatar_url, { responseType: "arraybuffer", timeout: 8000 })
      .then(r => Buffer.from(r.data)).catch(() => null);

    if (ppBuf) {
      await sock.sendMessage(m.chat, { image: ppBuf, caption: teks }, { quoted: m });
    } else {
      await m.reply(teks);
    }
    await m.react("✅");
  } catch (err) {
    await m.react("❌");
    if (err.response?.status === 404) return m.reply(`❌ User *${username}* tidak ditemukan!`);
    m.reply("❌ Gagal stalk GitHub: " + err.message);
  }
};

handler.command = ["githubstalk", "ghstalk", "github"];
handler.tags = ["search"];
handler.help = ["githubstalk <username>"];
module.exports = handler;

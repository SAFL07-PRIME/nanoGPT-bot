// plugins/stalker-game.js — FF & ML Stalker dari Shota Bot MD
const axios = require("axios");

const API = "https://api.nexray.eu.cc";

let handler = async (m, { sock, command, text }) => {

  // ── FF Stalk ───────────────────────────
  if (command === 'ffstalk' || command === 'stalkff') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} 2775229425`);
    await m.react('🎮');

    try {
      const { data } = await axios.get(`${API}/stalker/freefire?id=${text}`, { timeout: 15000 });
      if (!data?.status) throw new Error('Gagal ambil data!');
      const r = data.result || data;

      return m.reply(
        `🎮 *Free Fire Stalker*\n\n` +
        `╭┈┈⬡\n` +
        `┃ 🆔 ID: *${r.player_id || r.id || text}*\n` +
        `┃ 👤 Nickname: *${r.nickname || r.name || '-'}*\n` +
        `┃ 🏆 Level: *${r.level || '-'}*\n` +
        `┃ 🌍 Region: *${r.region || '-'}*\n` +
        `┃ 👥 Guild: *${r.guild || '-'}*\n` +
        `╰┈┈⬡`
      );
    } catch (e) {
      await m.react('❌');
      return m.reply('❌ Gagal! Cek ID-nya ya: ' + e.message);
    }
  }

  // ── ML Stalk ───────────────────────────
  if (command === 'mlstalk' || command === 'stalkml') {
    if (!text || !text.includes('|'))
      return m.reply(`*Contoh:*\n> ${m.cmd} 1343331387|15397\n\nFormat: ID|Zone`);
    await m.react('🎮');

    const [id, zone] = text.split('|').map(s => s.trim());
    try {
      const { data } = await axios.get(`${API}/stalker/mobilelegend?id=${id}&zone=${zone}`, { timeout: 15000 });
      if (!data?.status) throw new Error('Gagal ambil data!');
      const r = data.result || data;

      return m.reply(
        `🗡️ *Mobile Legends Stalker*\n\n` +
        `╭┈┈⬡\n` +
        `┃ 🆔 ID: *${id}*\n` +
        `┃ 🌐 Zone: *${zone}*\n` +
        `┃ 👤 Username: *${r.username || r.name || '-'}*\n` +
        `┃ 📍 Region: *${r.region || '-'}*\n` +
        `┃ 🏆 Rank: *${r.rank || '-'}*\n` +
        `╰┈┈⬡`
      );
    } catch (e) {
      await m.react('❌');
      return m.reply('❌ Gagal! Cek ID & Zone: ' + e.message);
    }
  }
};

handler.command = ['ffstalk', 'stalkff', 'mlstalk', 'stalkml'];
handler.tags = ['search'];
handler.help = ['ffstalk <id>', 'mlstalk <id>|<zone>'];
module.exports = handler;

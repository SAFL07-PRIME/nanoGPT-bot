// plugins/search-lirik.js — dari Ourin MD 3
const axios = require("axios");

async function fetchLyrics(query) {
  try {
    const res = await axios.get(
      `https://api.nexray.eu.cc/search/lyrics?q=${encodeURIComponent(query)}`,
      { timeout: 15000 }
    );
    return res.data?.result || null;
  } catch { return null; }
}

let handler = async (m, { sock }) => {
  const query = (m.text || "").trim();
  if (!query) return m.reply(
    `🎵 *ᴄᴀʀɪ ʟɪʀɪᴋ*\n\n` +
    `> Cari lirik lagu favorit kamu!\n\n` +
    `> *Contoh:*\n> ${m.cmd} sempurna andra and the backbone`
  );

  await m.react("🔍");

  try {
    const data = await fetchLyrics(query);

    if (!data?.lyrics?.plain_lyrics) {
      await m.react("❌");
      return m.reply(`😔 Lirik *${query}* tidak ditemukan. Coba kata kunci lebih spesifik!`);
    }

    const title = data.title || query;
    const artist = data.artist || data.lyrics?.artist_name || "Unknown";
    const lyrics = data.lyrics.plain_lyrics;

    // Potong kalau terlalu panjang
    const maxLen = 3000;
    const trimmed = lyrics.length > maxLen ? lyrics.slice(0, maxLen) + "\n\n_...lirik terpotong_" : lyrics;

    await m.react("✅");
    await m.reply(
      `🎵 *ʟɪʀɪᴋ ʟᴀɢᴜ*\n\n` +
      `╭┈┈⬡「 🎤 *INFO* 」\n` +
      `┃ 🎵 Judul: *${title}*\n` +
      `┃ 🎤 Artis: *${artist}*\n` +
      `╰┈┈⬡\n\n` +
      `${trimmed}`
    );
  } catch (err) {
    await m.react("❌");
    m.reply("❌ Gagal mencari lirik: " + err.message);
  }
};

handler.command = ["lirik", "lyric", "lyrics", "liriklagu"];
handler.tags = ["search"];
handler.help = ["lirik <judul lagu>"];
module.exports = handler;

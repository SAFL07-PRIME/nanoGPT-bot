// plugins/search-resep.js — Resep Masakan dari Shota Bot MD
const axios = require("axios");

let handler = async (m, { sock, command, text }) => {

  // ── Resep ──────────────────────────────
  if (command === 'resep' || command === 'masak' || command === 'caramasak') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} nasi goreng`);
    await m.react("🍳");
    await m.reply("🍳 Mencari resep...");

    try {
      const { data } = await axios.get(
        `https://api.nexray.eu.cc/search/resep?q=${encodeURIComponent(text)}`,
        { timeout: 15000 }
      );

      if (!data?.status || !data?.result?.length)
        return m.reply("❌ Resep tidak ditemukan. Coba kata lain!");

      const res = data.result[0];
      let caption =
        `🍳 *RESEP: ${(res.judul || text).toUpperCase()}*\n\n` +
        `› ⏱️ Waktu: ${res.waktu_masak || "-"}\n` +
        `› 🍽️ Porsi: ${res.hasil || "-"}\n` +
        `› 📊 Tingkat: ${res.tingkat_kesulitan || "-"}\n\n` +
        `*🛒 BAHAN-BAHAN:*\n${res.bahan || "-"}\n\n` +
        `*👨‍🍳 CARA MEMBUAT:*\n${res.langkah_langkah || "-"}`;

      if (res.thumbnail) {
        await sock.sendMessage(m.chat, {
          image: { url: res.thumbnail }, caption,
        }, { quoted: m.verifiedQuoted });
      } else {
        await m.reply(caption);
      }
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Error: " + e.message);
    }
  }

  // ── Emojimix ──────────────────────────
  if (command === 'emojimix' || command === 'mojimix' || command === 'mix') {
    if (!text || !text.includes("+"))
      return m.reply(`*Contoh:*\n> ${m.cmd} 😀+😍`);

    const [e1, e2] = text.split("+").map(s => s.trim());
    await m.react("⏳");

    try {
      const url = `https://api.jarroffc.my.id/tools/emojimix?apikey=jarroffc&emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`;
      const res = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
      const buf = Buffer.from(res.data);

      await sock.sendMessage(m.chat, {
        sticker: buf,
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("⚠️ Gagal mix emoji: " + e.message);
    }
  }

  // ── Pinterest search/download ──────────
  if (command === 'pinterest' || command === 'pin') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} aesthetic room\n> ${m.cmd} https://pin.it/xxx`);
    await m.react("⏳");

    try {
      // Search mode
      const { data } = await axios.get(
        `https://api.nexray.eu.cc/search/pinterest?q=${encodeURIComponent(text)}&limit=5`,
        { timeout: 15000 }
      );

      const items = data?.result || data?.results || [];
      if (!items.length) return m.reply("❌ Tidak ada hasil ditemukan!");

      for (const item of items.slice(0, 4)) {
        const imgUrl = item?.url || item?.image || item?.img;
        if (!imgUrl) continue;
        await sock.sendMessage(m.chat, {
          image: { url: imgUrl },
          caption: item?.title || "Pinterest",
        }, { quoted: m.verifiedQuoted }).catch(() => {});
        await new Promise(r => setTimeout(r, 500));
      }
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Error: " + e.message);
    }
  }
};

handler.command = ['resep', 'masak', 'caramasak', 'emojimix', 'mojimix', 'mix', 'pinterest', 'pin'];
handler.tags = ['search'];
handler.help = ['resep <makanan>', 'emojimix 😀+😍', 'pinterest <query>'];
module.exports = handler;

// plugins/daftar.js — Sistem Registrasi dari Ourin MD 3

let handler = async (m, { sock }) => {
  const user = global.db.users?.[m.sender];
  if (!user) return m.reply("❌ Data user tidak ditemukan.");

  if (user.registered) {
    return m.reply(`✅ Kamu sudah terdaftar!\n\n👤 Nama: ${user.name || m.pushName}\n🪙 Koin: ${user.koin}\n⚡ Energi: ${user.energi}`);
  }

  // Registrasi
  const reward = global.registrasiReward || { koin: 1000, energi: 100, exp: 1000 };
  user.registered = true;
  user.name = m.pushName || "Pengguna";
  user.koin = (user.koin || 0) + reward.koin;
  user.energi = (user.energi || 0) + reward.energi;
  user.exp = (user.exp || 0) + reward.exp;

  const teks = `
✅ *Registrasi Berhasil!*

👤 Nama: ${user.name}
📱 Nomor: ${m.sender.split("@")[0]}

*Reward Registrasi:*
🪙 Koin: +${reward.koin}
⚡ Energi: +${reward.energi}
📈 XP: +${reward.exp}

Selamat bergabung! Ketik *.menu* untuk melihat fitur.`;

  return m.reply(teks);
};

handler.command = ["daftar", "register", "reg"];
handler.tags = ["user"];
handler.help = ["daftar"];

module.exports = handler;

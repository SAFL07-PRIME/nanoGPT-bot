// plugins/leaderboard.js — dari Ourin MD 3

let handler = async (m, { sock, command }) => {
  const users = global.db?.users || {};
  const entries = Object.values(users).filter((u) => u && u.id);

  if (command === "topcoin" || command === "topkoin") {
    const sorted = entries.sort((a, b) => (b.koin || 0) - (a.koin || 0)).slice(0, 10);
    if (!sorted.length) return m.reply("❌ Belum ada data pengguna.");

    let teks = `🪙 *Top 10 Koin*\n\n`;
    sorted.forEach((u, i) => {
      const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`;
      teks += `${medal} ${u.name || u.id.split("@")[0]} — *${global.toRupiah(u.koin || 0)}* koin\n`;
    });
    return m.reply(teks);
  }

  if (command === "topexp" || command === "toplevel") {
    const sorted = entries.sort((a, b) => (b.exp || 0) - (a.exp || 0)).slice(0, 10);
    if (!sorted.length) return m.reply("❌ Belum ada data pengguna.");

    let teks = `📈 *Top 10 XP/Level*\n\n`;
    sorted.forEach((u, i) => {
      const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`;
      teks += `${medal} ${u.name || u.id.split("@")[0]} — *${global.toRupiah(u.exp || 0)}* XP\n`;
    });
    return m.reply(teks);
  }

  // Summary leaderboard
  const totalUser = entries.length;
  const totalPremium = (global.db?.settings?.premium || []).length;
  const totalHit = global.toRupiah(global.db?.settings?.totalhit || 0);

  return m.reply(`
📊 *Statistik Bot*

👤 Total User: *${totalUser}*
💎 Total Premium: *${totalPremium}*
📊 Total Command Used: *${totalHit}*

Gunakan:
• *.topcoin* — Lihat top koin
• *.topexp* — Lihat top XP`);
};

handler.command = ["leaderboard", "lb", "stats", "topcoin", "topkoin", "topexp", "toplevel"];
handler.tags = ["user"];
handler.help = ["leaderboard", "topcoin", "topexp"];

module.exports = handler;

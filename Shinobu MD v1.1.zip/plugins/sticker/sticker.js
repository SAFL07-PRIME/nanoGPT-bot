const fs = require("fs");

let handler = async (m, { sock }) => {
  let mime = m.mime || ""
  if (!/image|video/.test(mime)) return m.reply("Kirim/reply foto dengan ketik `.sticker`")

  if (/video/.test(mime)) {
    if ((m.quoted || m).seconds > 15) return m.reply("Video duration maximum 15 seconds!")
  }

  let qmsg = m.qmsg
  let media = await sock.downloadAndSaveMediaMessage(qmsg)

  await sock.sendSticker(m.chat, media, m, { packname: "wm: skyassistant" })
  await fs.unlinkSync(media)
}

handler.help = "sticker"
handler.command = ["sticker", "stiker", "sgif", "s"]
handler.tags = "Main"

module.exports = handler
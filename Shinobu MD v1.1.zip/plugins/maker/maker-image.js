// plugins/maker-image.js — Wasted, Wanted, Txt2Image dari Shota Bot MD
const axios = require("axios");
const FormData = require("form-data");
const { downloadContentFromMessage } = require("dekzymarket-cyber");

const API3 = "https://api.nexray.eu.cc";
const API1 = "https://api.botcahx.eu.org";

// ── Upload ke uguu.se ─────────────────────
async function uploadUguu(buffer, filename = "image.jpg") {
  const form = new FormData();
  form.append("files[]", buffer, filename);
  const { data } = await axios.post("https://uguu.se/upload.php", form, {
    headers: form.getHeaders(),
    timeout: 30000,
  });
  return data.files[0].url;
}

// ── Download media dari WA ─────────────────
async function downloadMedia(m) {
  const qmsg = m.quoted ? m.quoted : m;
  const msg = qmsg.msg || qmsg;
  const type = (msg.mimetype || "").split("/")[0];
  const stream = await downloadContentFromMessage(msg, type);
  let buf = Buffer.from([]);
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk]);
  return buf;
}

let handler = async (m, { sock, command, text }) => {

  // ── Wasted ─────────────────────────────
  if (command === 'wasted') {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!/image/.test(mime)) return m.reply(`Kirim atau reply foto dengan caption *${m.cmd}*`);

    await m.react("⏳");
    try {
      const buf = await downloadMedia(m);
      const url = await uploadUguu(buf, `wasted_${Date.now()}.jpg`);
      const { data } = await axios.get(`${API3}/editor/wasted?url=${encodeURIComponent(url)}`, {
        responseType: "arraybuffer", timeout: 30000,
      });
      await sock.sendMessage(m.chat, { image: Buffer.from(data), caption: "💀 *WASTED*" }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Wanted ─────────────────────────────
  if (command === 'wanted') {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!/image/.test(mime)) return m.reply(`Kirim atau reply foto dengan caption *${m.cmd}*`);

    await m.react("⏳");
    try {
      const buf = await downloadMedia(m);
      const url = await uploadUguu(buf, `wanted_${Date.now()}.jpg`);
      const { data } = await axios.get(`${API3}/editor/wanted?url=${encodeURIComponent(url)}`, {
        responseType: "arraybuffer", timeout: 30000,
      });
      await sock.sendMessage(m.chat, { image: Buffer.from(data), caption: "🤠 *WANTED*" }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── Txt2Image ──────────────────────────
  if (command === 'txt2img' || command === 'text2img') {
    if (!text) return m.reply(`*Contoh:*\n> ${m.cmd} orang makan mie ayam`);
    await m.react("⏳");
    await m.reply("🎨 Membuat gambar dari teks...");

    try {
      const params = new URLSearchParams({ apikey: "fgsiapi-1f33ce6d-6d", prompt: text });
      const res = await fetch(`https://fgsi.dpdns.org/api/ai/text2img/v1?${params}`);
      if (!res.ok) throw new Error("API Error " + res.status);
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(m.chat, {
        image: buffer,
        caption: `🎨 *Text to Image*\n> Prompt: ${text}`,
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal generate gambar: " + e.message);
    }
  }

  // ── Remini (HD) ────────────────────────
  if (command === 'remini' || command === 'hd') {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.startsWith("image/")) return m.reply("Reply atau kirim gambar dulu!");
    await m.react("⏳");
    await m.reply("🔍 Meningkatkan kualitas gambar...");

    try {
      const img = await downloadMedia(m);
      const form = new FormData();
      form.append("image", img, "image.jpg");
      form.append("scale", "2");
      const { data } = await axios.post("https://api2.pixelcut.app/image/upscale/v1", form, {
        headers: { ...form.getHeaders(), accept: "application/json", "x-client-version": "web" },
        timeout: 30000,
      });
      await sock.sendMessage(m.chat, { image: { url: data.result_url }, caption: "✅ *HD Enhancement*" }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal: " + e.message);
    }
  }

  // ── To Anime ──────────────────────────
  if (command === 'toanime' || command === 'anime') {
    const qmsg = m.quoted ? m.quoted : m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    if (!mime.startsWith("image/")) return m.reply("Reply atau kirim gambar dulu!");
    await m.react("⏳");
    await m.reply("🎌 Converting ke anime style...");

    try {
      const imgBuffer = await downloadMedia(m);
      const { data } = await axios.post(
        "https://ghibli-proxy.netlify.app/.netlify/functions/ghibli-proxy",
        {
          image: "data:image/png;base64," + imgBuffer.toString("base64"),
          prompt: "make anime art style",
          model: "gpt-image-1",
          n: 1,
          size: "auto",
          quality: "low",
        },
        {
          headers: {
            origin: "https://overchat.ai",
            referer: "https://overchat.ai/",
            "user-agent": "Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36",
          },
          timeout: 60000,
        }
      );
      const result = data?.data?.[0]?.b64_json;
      if (!result) throw new Error("Tidak ada hasil");
      await sock.sendMessage(m.chat, {
        image: Buffer.from(result, "base64"),
        caption: "🎌 *Anime Style*",
      }, { quoted: m.verifiedQuoted });
      await m.react("✅");
    } catch (e) {
      await m.react("❌");
      m.reply("❌ Gagal convert anime: " + e.message);
    }
  }
};

handler.command = ['wasted', 'wanted', 'txt2img', 'text2img', 'remini', 'hd', 'toanime', 'anime'];
handler.tags = ['maker'];
handler.help = [
  'wasted [reply foto]',
  'wanted [reply foto]',
  'txt2img <prompt>',
  'remini [reply foto]',
  'toanime [reply foto]',
];
module.exports = handler;

// plugins/ai.js — AI Chat dari Ourin MD 3 (Gemini + Groq)
const axios = require("axios");

// ── Gemini AI ─────────────────────────────
async function askGemini(prompt) {
  const apiKey = global.geminiApiKey;
  if (!apiKey) throw new Error("Gemini API Key belum diset di config.js");

  const res = await axios.post(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      contents: [{ parts: [{ text: prompt }] }],
    },
    { headers: { "Content-Type": "application/json" } }
  );

  return res.data?.candidates?.[0]?.content?.parts?.[0]?.text || "Tidak ada respons.";
}

// ── Groq AI ───────────────────────────────
async function askGroq(prompt) {
  const apiKey = global.groqApiKey;
  if (!apiKey) throw new Error("Groq API Key belum diset di config.js");

  const res = await axios.post(
    "https://api.groq.com/openai/v1/chat/completions",
    {
      model: "llama3-8b-8192",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1024,
    },
    {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
    }
  );

  return res.data?.choices?.[0]?.message?.content || "Tidak ada respons.";
}

// ── Handler ───────────────────────────────
let handler = async (m, { text, command }) => {
  if (!text) return m.reply(`*Contoh:*\n${m.cmd} Siapa presiden Indonesia?`);

  await m.reply("🤖 Sedang memproses...");

  try {
    let result = "";
    if (command === "gemini") {
      result = await askGemini(text);
    } else {
      result = await askGroq(text);
    }
    await m.reply(`🤖 *${command === "gemini" ? "Gemini" : "Groq AI"}*\n\n${result}`);
  } catch (err) {
    m.reply(`❌ Gagal: ${err.message}`);
  }
};

handler.command = ["ai", "bot", "gemini", "groq", "gpt"];
handler.tags = ["ai"];
handler.help = [
  "ai <pertanyaan>",
  "gemini <pertanyaan>",
  "groq <pertanyaan>",
];

module.exports = handler;

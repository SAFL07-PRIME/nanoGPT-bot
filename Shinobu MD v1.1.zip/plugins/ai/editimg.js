const FormData = require('form-data');

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || q.mediaType || ''

    if (!text) {
        return m.reply(
            `Contoh:\n${usedPrefix + command} ubah menjadi anime`
        )
    }

    if (!/image/.test(mime)) {
        return m.reply(
            `Reply gambar dengan caption\n${usedPrefix + command} <prompt>`
        )
    }

    try {
        await m.reply('⏳ Processing...')

        const buffer = await q.download()

        const form = new FormData()

        form.append(
            'image',
            new Blob([buffer], {
                type: mime
            }),
            'image.jpg'
        )

        form.append('prompt', text)

        const res = await fetch(
            global.API(
                'theresav',
                '/ai/deepai/edit', {},
                'apikey'
            ), {
                method: 'POST',
                body: form
            }
        )

        if (!res.ok) {
            const err = await res.text().catch(() => '')
            throw new Error(
                `Status ${res.status}${err ? ` - ${err}` : ''}`
            )
        }

        const result = Buffer.from(
            await res.arrayBuffer()
        )

        if (!result || result.length < 1000) {
            throw new Error('Hasil gambar tidak valid')
        }

        await conn.sendMessage(
            m.chat, {
                image: result,
                caption: `✅ Prompt: ${text}`
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error(e)
        m.reply(`❌ Error: ${e.message}`)
    }
}

handler.help = ['editimg']
handler.tags = ['ai']
handler.command = /^(editimg|deepedit)$/i
handler.register = true
handler.limit = true
handler.premium = true

module.exports = handler
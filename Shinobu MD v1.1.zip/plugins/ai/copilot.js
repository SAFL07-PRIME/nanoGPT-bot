/*
Fitur Copilot Think Deep
Note : AI Think, Realtime
Req fitur gasken langsung aja tag saya :
https://chat.whatsapp.com/KxRm9Sb1HC7DniozVhqtvh?mode=hqrt1
*/

const axios = require("axios");

const handler = async (m, { sock, usedPrefix, command, text }) => {
  try { 

    if (!text) {
      return sock.sendMessage(
        m.chat,
        { text: `mw tanya apa` },
        { quoted: m }
      );
    }

    const loading = await sock.sendMessage(
      m.chat,
      { text: "Lemiting..." },
      { quoted: m }
    );

    const url = `${global.api.free7}/ai/copilot-think?text=${encodeURIComponent(text)}`;
    const { data } = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; YPBot)"
      }
    });

    if (!data?.status) throw new Error("API Error");

    const answer = data.result || "Tidak ada jawaban.";

    await sock.sendMessage(
      m.chat,
      { text: answer, edit: loading.key },
      {}
    );

  } catch (e) {
    await sock.sendMessage(
      m.chat,
      { text: "Gagal memproses pertanyaan." },
      { quoted: m }
    );
  }
};

handler.command = ["copilot", "cpai"]
handler.tags = ["plugins"];
handler.help = "copilot", "cpai";;

module.exports = handler;